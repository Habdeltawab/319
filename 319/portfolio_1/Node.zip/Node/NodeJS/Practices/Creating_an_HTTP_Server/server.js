
//Getting the http module
var http = require('http');
var fs = require('fs'); //File system module


//404 Response, 404 means error.
function send404Response(response){

    response.writeHead(404, {"Content-Type": "text/plain"});
    response.write("Errorr 404: Page not found!");
    response.end();
}

/*
 * The request parameter is the clients request.
 * The response is what we are sending back.
 * Handlng a user request
 */
function onRequest(request, response){
    if(request.method == 'GET' && request.url == '/'){//connecting to the home page.
        response.writeHead(200, {"Content-Type" : "text/html"});//Sneding an html file.
        fs.createReadStream("./index.html").pipe(response);//Creating a readable stream. The pipe method means that we are going to send the information in the HTML fole through the response object.
    }else{
        send404Response(response); //Connected to a different page
    }
}


/*
 * The parameter of the create server method is what code you want to run when connected to a client.
 * The listen method just sets the port number to listen for requests. In this case our port number is 4444.
 */
http.createServer(onRequest).listen(4444);
console.log("The server is running...");















