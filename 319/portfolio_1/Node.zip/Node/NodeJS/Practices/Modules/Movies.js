
/*
 * In Modules we take a long code and breaking it up into different files.
 * These different files are called modules.
 */

//Printing the movie name and IMDB rating for the movie Avatar
function printAvatar(){
    console.log("Avatar: PG-13");
}

//Printing the movie name and IMDB rating for the movie Chappie
function printChappie(){
    console.log("Chappie: R");
}

//choosing which function you want to export into the main file to use.
module.exports.avatar = printAvatar;
module.exports.chappie = printChappie;