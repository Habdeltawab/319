
/*
 * In Modules we take a long code and breaking it up into different files.
 * These different files are called modules.
 */

//require() basically means that we require something to import.
var movies = require('./Movies');//It has to be in this form.
movies.avatar();//using the avatar variable we created in the Movies.js file.
movies.chappie();
