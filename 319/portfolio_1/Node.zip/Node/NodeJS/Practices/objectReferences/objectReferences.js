
var sam = {
    favFood: "chicken",
    favSeries: "Game of Thrones"
};

var someone = sam; //Referencing sam to someone, when sam.favFood is called, it is going to print B-Dubs.
someone.favFood = "B-Dubs";
console.log(sam.favFood);

/*
* The difference between == & ===
 */
console.log(20 == '20');//ture, it is comparing the values, but not types.
console.log(20 === '20');//false, comparing values and types