//prototyping is used to add cool methods, or properties to your objects in classes.

function user(){
    this.name = ""; //The "this" keyword is reffering to the object that is calling this method.
    this.power = 100;
    this.givePower = function givePower(selectedPlayer){
        selectedPlayer.power += 1;
        this.power -= 1;
        console.log(this.name + " gave one powerUp to " + selectedPlayer.name);
    }
}

var Hosam = new user();
var Mitra = new user();

//Initializing the names of each variable
Hosam.name = "Hosam";
Mitra.name = "Mitra";

//Giving powers to mitra
Hosam.givePower(Mitra);
/*Hosam.givePower(Mitra);
Hosam.givePower(Mitra);
Hosam.givePower(Mitra);
Hosam.givePower(Mitra);*/

console.log("Hosam's current power is: " + Hosam.power);
console.log("Mitra's current power is: " + Mitra.power);

/*Here we are using function prototypes to add additiona methods to the user class.
* Every instance in the user class has access to the uppercut function.
 */
user.prototype.uppercut = function uppercut(selectedPlayer){
    selectedPlayer.power -= 9;
    this.power += 9;
    console.log("\n" + this.name + " just uppercutted " + selectedPlayer.name);
};

//Using the uppercut function on hosam
Mitra.uppercut(Hosam);//Uppercutting Hosam
console.log("Hosam's current power is: " + Hosam.power);
console.log("Mitra's current power is: " + Mitra.power);

//Adding properties to objects
user.prototype.magicalPowers = "10,000";
console.log("\nMitra's magical powers are at level: " + Mitra.magicalPowers);
console.log("Hosam's magical powers are at level: " + Hosam.magicalPowers);
console.log("Bros, that is a lot of magical powers!!!!!");