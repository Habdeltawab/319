
//When using a core mosule you neglect the "./".
//You just type the module name
//That way node is aware of the fact that you are using core modules.
var fs = require('fs');//The file system module, it allowes you to read, write, and delete files.

//Creating a new text file
fs.writeFileSync("corn.txt", "Corn is good, corn is life");//first parameter is the file name, and the second parameter is what you want to be typed inside the file.

//Reading from a file
console.log(fs.readFileSync("corn.txt").toString());
