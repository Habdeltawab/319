/*
 * the path module is good when you are working with file paths.
 * it normalizes the slashes depending on your operating system.
 */

var path = require('path');
var websiteHome = "Desktop/Hosam//yastaEsfsha5/index.html";//An imaginary address for a file. just for testing
var websiteAbout = "Desktop/Hosam//yastaEsfsha5/about.html";//on purpose, I added 2 slashes after Hosam.

/*
 * Whenever you have a path for a file it is broken down into different locations.
 * like the main path, folder path, the file itself, etc.
 */
console.log(path.normalize(websiteHome));//fixes the slashes in the address
console.log(path.dirname(websiteAbout));//Gives you the directory of the path without the file name.
console.log(path.basename(websiteAbout));//Gives you the file name
console.log(path.extname(websiteAbout));//Tells you what type of file it is





