var movies = require('./movies');
console.log("Sarah's favorite movie is: " + favorite);

