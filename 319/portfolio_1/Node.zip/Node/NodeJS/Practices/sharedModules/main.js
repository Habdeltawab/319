require('./Hosam');
require('./Sarah');

/*
 * Here it is printing that both users like deadpool.
 * This is happening because that when Hosam first imported the module,
 * he directly changed the favMovie variable; when Sarah also imports the module,
 * she is referencing to the same object and since Sarah didn't change the value.
 * she is getting the new default value which is "Deadpool".
 */