
//Objects in node.js
var  person = {
    firstName: "Hosam",
    lastName: "Abdeltawab",
    age: 20

};

//Print out the value of person to the console.
console.log(person);

//Functions
function add(a,b){
    return a+b;
}
console.log(add(100,200));

//Functions set to variables
var printSomething = function() { //You don't need a function name
    console.log("We are going yo ACE this class!!!");
};
printSomething(); //Calling the variable

//We can assign functions to variables and then pass them into other functions.
setTimeout(printSomething, 5000); //This means "Wait 5 seconds (5000 milliseconds) then print (printsomething())"





