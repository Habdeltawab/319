
/**
 * A customer food order number function that prints out the order number
 * @param orderNumber the order number
 */
function placeOrder(orderNumber){
    console.log("Customer order: ", orderNumber);

    cookAndDeliver(function(){
        console.log("The food is ready, order number: ", orderNumber);
    });
}

/**
 * Simulating five second operation, every order takes five seconds to prepare
 * Querring the data base
 */
function cookAndDeliver(callBack) {
    setTimeout(callBack, 5000);
}

//Simulating the customers orders
placeOrder(1);
placeOrder(2);
placeOrder(3);
placeOrder(4);
placeOrder(5);
placeOrder(6);
placeOrder(7);