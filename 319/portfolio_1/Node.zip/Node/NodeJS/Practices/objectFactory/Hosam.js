var movies = require('./movies');
favorite = movies.favMovie = "Deadpool";
console.log("Hosam's favorite movie is: " + favorite);
