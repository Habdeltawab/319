var movies = require('./movies');
favorite = movies.favMovie = "The Notebook";
console.log("Sarah's favorite movie is: " + favorite);

