/*
 * Here we are creating a new function that returns a new object.
 * This way will let every user have his/her unique favMovie.
 */

module.exports = function(){
    return{
        favMovie: ""
    }


};
