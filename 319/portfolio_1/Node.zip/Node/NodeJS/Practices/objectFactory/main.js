require('./Hosam');
require('./Sarah');

/*
 * this is called an object factory.
 * it is an object that is responsible for creating other objects.
 * So they can each have their custom copy.
 */