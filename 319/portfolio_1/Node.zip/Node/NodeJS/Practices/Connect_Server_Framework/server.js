//To install the connect module you go to the terminal and typ: npm install connect.

var connect = require('connect');
var http = require('http');

var app = connect();

//First function to be called.
function doFirst(request, response, next){
    console.log("First function executing");
    next();//This method calls the next function or object in the stack which is doSecond
}

//Second function to be called
function doSecond(request, response, next){
    console.log("Second function executing");
   // next();
}

//Calling the functions: This is the stack
app.use(doFirst);
app.use(doSecond);

http.createServer(app).listen(5555);
console.log(("Server is listening on port 5555...."));

