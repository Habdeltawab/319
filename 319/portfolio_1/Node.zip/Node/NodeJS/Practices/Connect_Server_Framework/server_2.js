//To install the connect module you go to the terminal and typ: npm install connect.

var connect = require('connect');
var http = require('http');

var app = connect();

function profile(request, response){
    console.log("User has requested profile....");
}

function forum(request, response){
    console.log("User has requested forum...");
}

/*
 *Whenever the user makes a request 'profile'. The function profile is used (th one in the second parameter).
 *To request any of the pages on a browesr you type (localhost:6666/profile).
 * I used google chrome
 */
app.use('./profile', profile);
app.use('./forum', forum);

http.createServer(app).listen(6666);
console.log(("Server is listening on port 5555...."));

