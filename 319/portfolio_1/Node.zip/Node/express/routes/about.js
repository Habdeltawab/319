var express = require('express');
var router = express.Router();

/* GET about Hosam page. */
router.get('/', function(req, res, next) {
    res.render('about', {
        title: 'About Hosam Abdeltawab',
        name: 'Hosam'

    });
});

module.exports = router;
