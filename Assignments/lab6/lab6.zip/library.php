<?php
session_start();
require ('functions.php');
$DB_uName = "dbu319team115";//root
$DB_password = "NWUyYmUwNWZh";//root
$DB_server = "mysql.cs.iastate.edu";//127.0.0.1
$DB_name = "db319team115";//UDB
$username = $_SESSION['userN'];

//Log-Out
if(isset($_POST['logout'])){
  session_destroy();
}

//Borrow A book
if(isset($_POST['borrowID'])){
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
  $ID = $_POST['borrowID'];

    //SQL commands.
    $checkBorrowed= "SELECT * FROM LoanHistory WHERE username='$username'";//Select if any.
    $allBooks = "SELECT * FROM Books WHERE Availability=0";

    //Querys.
    $data=mysqli_query($conn,$checkBorrowed);
    $booksData = mysqli_query($conn,$allBooks);

    //Arrays.
    $uName = array();//How many usernames are there.
    $rDate = array();//returned dates
    $emptyDate = array();//empty returned dates.
    $borrowedBooks= array();//keep track of the checked out books.

    //Move the data into array to make is easier to search.
    while($row=mysqli_fetch_array($data)){//Updating the arrays.
      array_push($uName, $row['Username']);
      array_push($rDate,$row['ReturnedDate']);
    }

    while($bRow = mysqli_fetch_array($booksData)){//Updating the arrays.
      array_push($borrowedBooks,$bRow['BookID']);
    }

    //Get all the empty dates
    for($i = 0; $i < sizeof($rDate); $i++){//Updating the arrays.
      if($rDate[$i] == ''){
        array_push($emptyDate,$rDate);
      }
    }

    // //Testing
    // echo "\n";
    // echo "Username array: ".print_r($uName)."\n";
    // echo "ReturnD array: ".print_r($rDate)."\n";
    // echo "Borrowed books: ".print_r($borrowedBooks)."\n";
    // echo "Size of the username array: ". sizeof($uName)."\n";
    // echo "Size of the rDate array: ".sizeof($rDate)."\n";
    // echo "Size of the empty dates array: ".sizeof($emptyDate)."\n";
    // echo "Size of the borrowed books array: ".sizeof($borrowedBooks)."\n";

    //Check if the student check out 2 books.
    if(sizeof($emptyDate) == 2 ){
      echo "\nYou checked out a lot of books...\n";
    }else if (checkIfBorrowed($borrowedBooks,$ID)) {
      echo "\nThe book is already checked out...\n";
    }else {//Borrow the book
      $borrowedBook = $_POST['borrowID'];
       date_default_timezone_set("America/Chicago");
       $dueDay = date("d") + 7;
       $dueMonth = date("m");
       $dueYear = date("Y");
       $dueDate = $dueYear."-".$dueMonth."-".$dueDay;

       $Availability = "UPDATE `Books` SET Availability=0 WHERE BookID=".$borrowedBook;
       $history = "INSERT INTO `LoanHistory`(`Username`, `BookID`, `DueDate`, `ReturnedDate`) VALUES ('$username', '$borrowedBook', '$dueDate',NULL)";
       mysqli_query($conn, $history);
       mysqli_query($conn, $Availability);
    }
}

//Return A book
if(isset($_POST['returnID'])){
  date_default_timezone_set("America/Chicago");//Setting the timezone.
  $ID = $_POST['returnID'];//Book's ID to be returned.
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);

  //SQL commands.
  $emptyDate = "SELECT * FROM LoanHistory WHERE ReturnedDate IS NULL";//Get everything for the username who wants to return.

  //Querys.
  $emptyData = mysqli_query($conn, $emptyDate);
  if(!$emptyData){
    printf("Error yazmeel: %s\n", mysqli_error($conn));
  }

  //Arrays;
  $usernames = array();
  $bookIds = array();
  $ReturnDates = array();
  $emptyReturnDates = array();

  //Updating the arrays.
  while($userRow = mysqli_fetch_array($emptyData)){
    array_push($usernames,$userRow['Username']);
    array_push($bookIds,$userRow['BookID']);
    array_push($ReturnDates,$userRow['ReturnedDate']);
  }

  //Testing.
  echo "\n";
  echo "Usernames in the username array: ".print_r($usernames)."\n";
  echo "Books IDs array: ".print_r($bookIds)."\n";
  echo "Empty dates array: ".print_r($emptyReturnDates)."\n";
  echo "The size of Usernames array: ". sizeof($usernames)."\n";
  echo "The size of Books IDs array: ". sizeof($bookIds)."\n";
  echo "The size of the empty dates array: ".sizeof($emptyReturnDates)."\n";

  //Setting the current date.
  $returnDay = date("d");
  $returnMonth = date("m");
  $returnYear = date("Y");
  $returnDate = $returnYear."-".$returnMonth."-".$returnDay;

  //Move the empty returned dates into an array.
  for($j = 0; $j < sizeof($ReturnDates); $j++){
    if($ReturnDates[$j] == ''){
      array_push($emptyReturnDates,$ReturnDates[$j]);
    }
  }
  //Testing.
  echo "\n";
    echo "The size empty dates array: ". sizeof($emptyReturnDates)."\n";
    echo "The size not empty dates array: ". sizeof($ReturnDates)."\n";
    echo "\n";

  //Check the user Wants to return.
  for($i = 0; $i < sizeof($emptyReturnDates); $i++){
    echo "\n";
    echo "Username: ".$usernames[$i]."\n";
    echo "Book ID".$bookIds[$i]."\n";
    echo "Return Date: ".$emptyReturnDates[$i]."\n";
    echo "\n";
    if($usernames[$i] == $username && $bookIds[$i] == $ID && $emptyReturnDates[$i] == ''){
      $Availability = "UPDATE `Books` SET Availability=1 WHERE BookID=".$ID;//Updating the availability.
      $history="UPDATE `LoanHistory` SET `ReturnedDate`='$returnDate' WHERE `BookID`=".$ID;//Updating the table
      mysqli_query($conn, $history);
      mysqli_query($conn, $Availability);
      $result = mysqli_query($conn, $history);
      $result_2 = mysqli_query($conn, $Availability);

      echo "I am Here, I am Working. WTF!!!!!!";

      if(!$result){
        printf("WTF History Error: %s\n", mysqli_error($conn));
      }

      if(!$result_2){
        printf("WTF Availability Error: %s\n", mysqli_error($conn));
      }

    }
  }
}

$art= "SELECT * FROM  `Books` WHERE BookID%4=0";//Art Books.
$science= "SELECT * FROM  `Books` WHERE BookID%4=1";//Science books.
$sport= "SELECT * FROM  `Books` WHERE BookID%4=2";//Sport books.
$literature= "SELECT * FROM  `Books` WHERE BookID%4=3";//literature books.

//Create a connection
$conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
$artB = mysqli_query($conn,$art);
$scienceB = mysqli_query($conn,$science);
$sportB = mysqli_query($conn,$sport);
$literatureB = mysqli_query($conn,$literature);

//Printing the Username
echo "
<div id='username'>
<h2>Username: ".$username."</h2>
<form id='logoutForm' action='index.html'>
<input type='button' id='logOut' value='Log-Out' /><br />
</form>
</div><br />

";
//Printing the table
echo "
<table id='myTable' border=2>
  <tr>
    <th>Art</th>
    ";
    while($artRow = mysqli_fetch_array($artB)){
      echo "<td id='
      Book ID: ".$artRow['BookID']."<br />
      Book Title: ".$artRow['BookTitle']."<br />
      Book Author: ".$artRow['Author']."<br />
      Availability: ".$artRow['Availability']."
      '>".$artRow['BookTitle']."</td>";
    }

    echo "</tr><tr>
      <th>Science</th>
    ";
    while($scienceRow = mysqli_fetch_array($scienceB)){
      echo "<td id='
      Book ID: ".$scienceRow['BookID']."<br />
      Book Title: ".$scienceRow['BookTitle']."<br />
      Book Author: ".$scienceRow['Author']."<br />
      Availability: ".$scienceRow['Availability']."
      '>".$scienceRow['BookTitle']."</td>";
    }

    echo "</tr><tr>
      <th>Sport</th>
    ";
    while($sportRow = mysqli_fetch_array($sportB)){
      echo "<td id='
      Book ID: ".$sportRow['BookID']."<br />
      Book Title: ".$sportRow['BookTitle']."<br />
      Book Author: ".$sportRow['Author']."<br />
      Availability: ".$sportRow['Availability']."
      '>".$sportRow['BookTitle']."</td>";
    }

    echo "</tr><tr>
      <th>Literature</th>
    ";
    while($literatureRow = mysqli_fetch_array($literatureB)){
      echo "<td id='
      Book ID: ".$literatureRow['BookID']."<br />
      Book Title: ".$literatureRow['BookTitle']."<br />
      Book Author: ".$literatureRow['Author']."<br />
      Availability: ".$literatureRow['Availability']."
      '>".$literatureRow['BookTitle']."</td>";
    }
        echo "</tr>";
        echo "</table>";
        echo "<br />";
        mysqli_close($conn);
 ?>
<html>
<head>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
</head>

<body>

    Enter a book ID: <input type="text" id="borrwBook" placeholder="Book ID"/>
    <input type="button" id="borrow" value="Borrow book"/><br />

    Return Book: <input type="text" id="returnID" placeholder="Borrowed book ID" />
    <input type="button" id="returnBook" value="Return"; />
  <h3></h3>

<script>
$(document).ready(function(){
  $("td").click(function(){
      $("h3").html(this.id);
  });
  $("#borrow").click(function(){
    $.ajax({
      url: "library.php",
      type: "POST",
      data: {borrowID:$("#borrwBook").val()},
      success: function(e){
        console.log(e);
      }
    });

  });

$("#returnBook").click(function(){
  $.ajax({
    url: "library.php",
    type: "POST",
    data: {returnID:$("#returnID").val()},
    success: function(e){
      console.log(e);
    }
  });
});

$("#logOut").click(function(){
  $.ajax({
    url: "library.php",
    type:"POST",
    data: {logout: "destroy"},
    success: function(){
      $("#logoutForm").submit();
    }
  });
});

});

</script>
</body>

<style>
td:hover{
  background-color: aqua;
}

#username {
  position:absolute;
   top:5;
   right:30;
   color: red;
}
#logout{
  position: absolute;
  top: -5;
  right: 30;
  background: #a9014b repeat-x;
  display: inline-block;
  padding: 5px 10px 6px;
  color: #fff;
  text-decoration: none;
  font-weight: bold;
  line-height: 1;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  -moz-box-shadow: 0 1px 3px #999;
  -webkit-box-shadow: 0 1px 3px #999;
  text-shadow: 0 -1px 1px #222;
  border-bottom: 1px solid #222;
  cursor: pointer;
}
</style>
</html>
