<?php
require('functions.php');
$DB_uName = "dbu319team115";//root
$DB_password = "NWUyYmUwNWZh";//root
$DB_server = "mysql.cs.iastate.edu";//127.0.0.1
$DB_name = "db319team115";//UDB
$fName = $_POST["fname"];
$lName = $_POST["lname"];
$uName = $_POST["username"];
$password = $_POST["password"];
$cPass = $_POST["cpass"];
$email = $_POST["email"];
$phone = $_POST["phone"];

if(isset($_POST["cbox"])){
  $cBox= $_POST["cbox"];
}

//Create a connection
$conn = mysqli_connect($DB_server,$DB_uName, $DB_password);

//Check connection
if(!$conn){
  die("Connection failed: " .mysqli_connect_error());
}


//Create a database if it doesn't exists.
//$dataBase = "CREATE DATABASE IF NOT EXISTS UDB";//Create DATABASE
// //Check if databse is created.
// if (mysqli_query($conn, $usersDB)) {
//     echo "Database created successfully";
// } else {
//     echo "Error creating database: " . mysqli_error($conn);
// }
$usersDB = "db319team115";//UDB"
$conn_2 = mysqli_connect($DB_server,$DB_uName, $DB_password, $usersDB);

//Cleaning the variables
$fName = mysqli_real_escape_string($conn_2, $_POST["fname"]);
$lName = mysqli_real_escape_string($conn_2, $_POST["lname"]);
$uName = mysqli_real_escape_string($conn_2, $_POST["username"]);

$email = mysqli_real_escape_string($conn_2, $_POST["email"]);
$phone = mysqli_real_escape_string($conn_2, $_POST["phone"]);

if(isset($_POST["cbox"])){
$cBox= 1;
//mysqli_real_escape_string($conn_2, $_POST["cbox"]);
}

if(checkFName($fName) &&checkLName($lName) && checkUsername($uName) &&checkPass($password,$cPass) &&checkEmail($email) &&  checkPhone($phone) && isset($cBox)){
  $password = md5(mysqli_real_escape_string($conn_2, $_POST["password"]));
  $cPass = md5(mysqli_real_escape_string($conn_2, $_POST["cpass"]));
echo "everything is fine!!!<br />";

//Users table
$usersT = "CREATE TABLE IF NOT EXISTS Users (
FirstName VARCHAR(255) NOT NULL,
LastName VARCHAR(255) NOT NULL,
Username VARCHAR(255) NOT NULL PRIMARY KEY,
Password VARCHAR(255) NOT NULL,
Email VARCHAR(255) NOT NULL,
Phone INT(10)  NOT NULL,
Checkbox TINYINT(127) NOT NULL
)";

// //SQL to resize the columns
// $resize = "ALTER TABLE Users MODIFY Password VARCHAR(255)";
mysqli_query($conn_2, $usersT);
 $usersData = "INSERT INTO Users (FirstName,LastName,Username,Password,Email,Phone,Checkbox) VALUES ('$fName','$lName','$uName','$password','$email','$phone','$cBox')";

//Check if record is created.
if(mysqli_query($conn_2, $usersData)){
  echo "New record created successfully!";
  header('location: index.html');
}else{
  echo "Error: " . $usersData . "<br>" . mysqli_error($conn_2);
}

mysqli_close($conn);
}else {
  echo "Make sure everything is filled and/or checked...<br />";
}
?>
