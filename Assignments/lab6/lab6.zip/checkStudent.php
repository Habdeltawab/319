<?php
  session_start();
  require('functions.php');
  $uName = $_SESSION['userN'];
  $pass = md5($_SESSION['userP']);
  $DB_uName = "dbu319team115";//root
  $DB_password = "NWUyYmUwNWZh";//root
  $DB_server = "mysql.cs.iastate.edu";//127.0.0.1
  $DB_name = "db319team115";//UDB

  //Search for the passed in username and password combination.
  $searchQ = "SELECT * FROM  Users
        WHERE Username LIKE ('$uName') AND password LIKE ('$pass')";

  //Create a connection
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);

  //Fetching the data
  $row = mysqli_fetch_assoc(mysqli_query($conn,$searchQ));

  //Comparing the data.
if(strcmp(mb_strtolower($uName), mb_strtolower($row['Username'])) == 0 && strcmp($pass, mb_strtolower($row['Password'])) == 0){
  //On success, go to the library.
  header('location:library.php');
}else{
  //On faliure, redirect back to the Index page.
  header('location: index.html');
}
?>
