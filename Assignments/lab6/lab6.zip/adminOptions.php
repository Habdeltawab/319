<?php
require("functions.php");
session_start();
$action = $_POST['button'];//The request of the admin.
$DB_uName = "dbu319team115";//root
$DB_password = "NWUyYmUwNWZh";//root
$DB_server = "mysql.cs.iastate.edu";//127.0.0.1
$DB_name = "db319team115";//UDB

//If admin wantes to add a book.
if($action == "add"){
  $title = $_POST['title'];
  $author= $_POST['author'];
  $genre = $_POST['genre'];
  $_SESSION['genre'] = $genre;

  //Setting the ID.
  if(mb_strtolower($genre) == "art"){
    $ID = ArtID();
    $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);  //Create a connection
    $countSQL = "SELECT * FROM Books WHERE BookID%4=0";
    $data = mysqli_query($conn, $countSQL);
    $howMany = array();

    while($books = mysqli_fetch_array($data)){
      array_push($howMany,$books['BookTitle']);
    }
    if(sizeof($howMany) != 20){
    $sql ="INSERT INTO `Books` (`BookID`,`BookTitle`,`Author`,`Availability`) VALUES ('$ID','$title','$author','1')";//SQL to add a book
    mysqli_query($conn, $sql);//Add the book.
    echo "Added the book successfully\n";//The book is added
    echo"Book Title: ".$title."\n";
    echo "Book Author: ".$author."\n";
    echo "Book Genre: ".$genre;
        }

  }else if (mb_strtolower($genre) == "sport"){
    $ID = sportID();
    $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);  //Create a connection
    $countSQL = "SELECT * FROM Books WHERE BookID%4=2";
    $data = mysqli_query($conn, $countSQL);
    $howMany = array();

    while($books = mysqli_fetch_array($data)){
      array_push($howMany,$books['BookTitle']);
    }
    if(sizeof($howMany) != 20){
    $sql ="INSERT INTO `Books` (`BookID`,`BookTitle`,`Author`,`Availability`) VALUES ('$ID','$title','$author','1')";//SQL to add a book
    mysqli_query($conn, $sql);//Add the book.
    echo "Added the book successfully\n";//The book is added
    echo"Book Title: ".$title."\n";
    echo "Book Author: ".$author."\n";
    echo "Book Genre: ".$genre;
        }

  }else if(mb_strtolower($genre) == "science"){
      $ID = scienceID();
      $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);  //Create a connection
      $countSQL = "SELECT * FROM Books WHERE BookID%4=1";
      $data = mysqli_query($conn, $countSQL);
      $howMany = array();

      while($books = mysqli_fetch_array($data)){
        array_push($howMany,$books['BookTitle']);
      }
      if(sizeof($howMany) != 20){
      $sql ="INSERT INTO `Books` (`BookID`,`BookTitle`,`Author`,`Availability`) VALUES ('$ID','$title','$author','1')";//SQL to add a book
      mysqli_query($conn, $sql);//Add the book.
      echo "Added the book successfully\n";//The book is added
      echo"Book Title: ".$title."\n";
      echo "Book Author: ".$author."\n";
      echo "Book Genre: ".$genre;
          }

    }else if(mb_strtolower($genre) == "literature"){
      $ID = literatureID();
      $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);  //Create a connection
      $countSQL = "SELECT * FROM Books WHERE BookID%4=3";
      $data = mysqli_query($conn, $countSQL);
      $howMany = array();

      while($books = mysqli_fetch_array($data)){
        array_push($howMany,$books['BookTitle']);
      }
      if(sizeof($howMany) != 20){
      $sql ="INSERT INTO `Books` (`BookID`,`BookTitle`,`Author`,`Availability`) VALUES ('$ID','$title','$author','1')";//SQL to add a book
      mysqli_query($conn, $sql);//Add the book.
      echo "Added the book successfully\n";//The book is added
      echo"Book Title: ".$title."\n";
      echo "Book Author: ".$author."\n";
      echo "Book Genre: ".$genre;
          }
    }else{
      echo "555555555 a7a nek yalla!!!!";
    }

}else if($action == "delete"){
  $bookID = $_POST['bookID'];
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);  //Create a connection
  $sql ="DELETE FROM `Books` WHERE BookID = '$bookID'";
  mysqli_query($conn, $sql);//Add the book.
  echo "Book deleted successfully\n";//The book is deleted
  echo "Book ID: ".$bookID."\n";

}else if($action == "history"){
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
  $history = "SELECT * FROM LoanHistory";
  $data = mysqli_query($conn, $history);

  echo "
<table border = 2>
  <tr>
    <th>Username</th>
    <th>BookID</th>
    <th>Due Date</th>
    <th>Returned Date</th>
    </tr>
    ";
  while($row = mysqli_fetch_array($data)){
    echo "<tr>";
      echo "<td>".$row['Username']."</td>";
      echo "<td>".$row['BookID']."</td>";
      echo "<td>".$row['DueDate']."</td>";
      echo "<td>".$row['ReturnedDate']."</td>";
      echo "</tr>";
  }
      echo "</table>";
      echo "<br />";
      mysqli_close($conn);

}else if($action == "shelves"){
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
  $shelves = "SELECT * FROM Shelves";
  $data = mysqli_query($conn, $shelves);

  echo "
<table border = 2>
  <tr>
    <th>Shelf ID</th>
    <th>Shelf Name</th>
    </tr>
    ";
  while($row = mysqli_fetch_array($data)){
    echo "<tr>";
      echo "<td>".$row['ShelfID']."</td>";
      echo "<td>".$row['ShelfName']."</td>";
      echo "</tr>";
  }
      echo "</table>";
      echo "<br />";
      mysqli_close($conn);
}

//Adding the books to the right shelves.
$conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);


//Getting the books
$artBooks = "SELECT * FROM Books WHERE BookID%4=0";
$scienceBooks = "SELECT * FROM Books WHERE BookID%4=1";
$sportBooks = "SELECT * FROM Books WHERE BookID%4=2";
$literatureBooks = "SELECT * FROM Books WHERE BookID%4=3";

//Gettin the shelves.
$artShelf = "SELECT * FROM Shelves WHERE ShelfID%4=0";
$scienceShelf = "SELECT * FROM Shelves WHERE ShelfID%4=1";
$sportShelf = "SELECT * FROM Shelves WHERE ShelfID%4=2";
$literatureShelf = "SELECT * FROM Shelves WHERE ShelfID%4=3";

//Shelf Data.
$artShelfData = mysqli_query($conn, $artShelf);
$scienceShelfData = mysqli_query($conn, $scienceShelf);
$sportShelfData = mysqli_query($conn, $sportShelf);
$literatureShelfData = mysqli_query($conn, $literatureShelf);

//Check if there are errors.
if(!$artShelfData){
  printf("Art Error: %s\n", mysqli_error($conn));
}
if(!$scienceShelfData){
  printf("scienceError: %s\n", mysqli_error($conn));
}
if(!$sportShelfData){
  printf("sport Error: %s\n", mysqli_error($conn));
}
if(!$literatureShelfData){
  printf("literature Error: %s\n", mysqli_error($conn));
}


//Books Data.
$artData = mysqli_query($conn, $artBooks);
$scienceData = mysqli_query($conn, $scienceBooks);
$sportData = mysqli_query($conn, $sportBooks);
$literatureData = mysqli_query($conn, $literatureBooks);


//Check if there are errors.
if(!$artData){
  printf("Art Error: %s\n", mysqli_error($conn));
}
if(!$scienceData){
  printf("science Error: %s\n", mysqli_error($conn));
}
if(!$sportData){
  printf("sport Error: %s\n", mysqli_error($conn));
}
if(!$literatureData){
  printf("literature Error: %s\n", mysqli_error($conn));
}

//Shelf Arrays;
$shelfArt = array();
$shelfScience = array();
$shelfSport = array();
$shelfLiterature = array();

//Book Arrays.
$artArray = array();
$scienceArray = array();
$sportArray = array();
$literatureArray = array();

//Copying the shelf data into the Arrays.
while($shelfRow = mysqli_fetch_array($artShelfData)){
  array_push($shelfArt,$shelfRow['ShelfID']);
}
while($shelfRow = mysqli_fetch_array($scienceShelfData)){
  array_push($shelfScience,$shelfRow['ShelfID']);
}
while($shelfRow = mysqli_fetch_array($sportShelfData)){
  array_push($shelfSport,$shelfRow['ShelfID']);
}
while($shelfRow = mysqli_fetch_array($literatureShelfData)){
  array_push($shelfLiterature,$shelfRow['ShelfID']);
}

//Copying book data into the arrays.
while($artRow = mysqli_fetch_array($artData)){
  array_push($artArray, $artRow['BookID']);
}
while($scienceRow = mysqli_fetch_array($scienceData)){
  array_push($scienceArray, $scienceRow['BookID']);
}
while($sportRow = mysqli_fetch_array($sportData)){
  array_push($sportArray, $sportRow['BookID']);
}
while($literatureRow = mysqli_fetch_array($literatureData)){
  array_push($literatureArray, $literatureRow['BookID']);
}

//Inserting into art.
for($i = 0; $i < sizeof($artArray); $i++){
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
  $ID=$artArray[$i];
  $value = $shelfArt[0];
  //Inserting commands.
  $artSQL = "INSERT INTO BooksLocation (BookID, shelfID) VALUES ('$ID','$value')";
  mysqli_query($conn,$artSQL);
}

//Inserting into science.
for($j = 0; $j < sizeof($scienceArray); $j++){
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
  $ID=$scienceArray[$j];
  $value = $shelfScience[0];
  //Inserting commands.
  $scienceSQL = "INSERT INTO BooksLocation (BookID, shelfID) VALUES ('$ID','$value')";
  mysqli_query($conn,$scienceSQL);
}

//Inserting into art.
for($k = 0; $k < sizeof($sportArray); $k++){
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
  $ID=$sportArray[$k];
  $value = $shelfSport[0];
  //Inserting commands.
  $sportSQL = "INSERT INTO BooksLocation (BookID, shelfID) VALUES ('$ID','$value')";
  mysqli_query($conn,$sportSQL);
}

//Inserting into art.
for($z = 0; $z < sizeof($literatureArray); $z++){
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);
  $ID=$literatureArray[$z];
  $value = $shelfLiterature[0];
  //Inserting commands.
  $literatureSQL = "INSERT INTO BooksLocation (BookID, shelfID) VALUES ('$ID','$value')";
  mysqli_query($conn,$literatureSQL);
}

 ?>
