<?php
  require("functions.php");
  session_start();
  $uName = mb_strtolower($_POST["username"]);
  $pass =mb_strtolower($_POST["password"]);
  $DB_uName = "dbu319team115";//root
  $DB_password = "NWUyYmUwNWZh";//root
  $DB_server = "mysql.cs.iastate.edu";//127.0.0.1
  $DB_name = "db319team115";//UDB
  $_SESSION['userN'] = $uName;
  $_SESSION['userP'] = $pass;

  //Create a connection
  $conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);

  //Check connection
  if(!$conn){
    die("Connection failed: " .mysqli_connect_error());
  }

  // //Delete a row SQL code.
  // $Delete = "DELETE FROM Users WHERE Username = 'mAlkatheery' ";
  // mysqli_query($conn, $Delete);

  // //Change to a primary Key SQL code.
  // $PK = "ALTER TABLE Users ADD PRIMARY KEY(Username) ";
  // mysqli_query($conn, $PK);


  //Books Table
  $booksT = "CREATE TABLE IF NOT EXISTS Books (
  BookID INT(10) PRIMARY KEY,
  BookTitle VARCHAR(255) NOT NULL,
  Author VARCHAR(255) NOT NULL,
  Availability TINYINT(127)
  )";

  mysqli_query($conn, $booksT);
  //Check if table is created.
  // if (mysqli_query($conn, $booksT)) {
  //     echo "Table created successfully";
  // } else {
  //     echo "Error creating the table: " . mysqli_error($conn);
  // }

  //LoanHistory Table
  $loanT = "CREATE TABLE IF NOT EXISTS LoanHistory (
  Username VARCHAR(255),
  BookID INT(10) NOT NULL,
  DueDate DATE,
  ReturnedDate DATE
  )";

  //  $loanT = "DROP TABLE loanhistory";
  mysqli_query($conn, $loanT);

  // //Check if table is created.
  // if (mysqli_query($conn, $loanT)) {
  //     echo "Table created successfully";
  // } else {
  //     echo "Error creating the table: " . mysqli_error($conn);
  // }

  //Shelves Table
  $shelvesT = "CREATE TABLE IF NOT EXISTS Shelves (
  ShelfID INT(10) PRIMARY KEY,
  ShelfName VARCHAR(255) NOT NULL
  )";

mysqli_query($conn, $shelvesT);
  // //Check if table is created.
  // if (mysqli_query($conn, $shelvesT)) {
  //     echo "Table created successfully";
  // } else {
  //     echo "Error creating the table: " . mysqli_error($conn);
  // }


  //Books Location Table
  $booksLocationT = "CREATE TABLE IF NOT EXISTS BooksLocation (
  BookID INT(10) PRIMARY KEY,
  ShelfID INT(10) NOT NULL
  )";
mysqli_query($conn, $booksLocationT);
  // //Check if table is created.
  // if (mysqli_query($conn, $booksLocationT)) {
  //     echo "Table created successfully";
  // } else {
  //     echo "Error creating the table: " . mysqli_error($conn);
  // }

  mysqli_close($conn);

  if($uName != "admin" && $pass != "admin"){
        header('location: checkStudent.php');
  }else if(mb_strtolower($uName) == "admin" && mb_strtolower($pass) == "admin"){
        header('location: adminLibrary.php');
  }
