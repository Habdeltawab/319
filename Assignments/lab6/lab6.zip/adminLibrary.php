<?php
session_start();
require ('functions.php');
$DB_uName = "dbu319team115";//root
$DB_password = "NWUyYmUwNWZh";//root
$DB_server = "mysql.cs.iastate.edu";//127.0.0.1
$DB_name = "db319team115";//UDB
$username = $_SESSION['userN'];

//Log-Out
if(isset($_POST['logout'])){
  session_destroy();
}

$conn = mysqli_connect($DB_server,$DB_uName, $DB_password,$DB_name);  //Create a connection

//Setting the shelves IDs
$artShelf = ArtID();
$scienceShelf = scienceID();
$sportShelf = sportID();
$litShelf = literatureID();


//Printing the Username
echo "
<div id='username'>
<h2>Username: ".$username."</h2>
<form id='logoutForm' action='index.html'>
<input type='button' id='logOut' value='Log-Out' /><br />
</form>
</div><br />

";

// //Adding the shelves
// $artS= "INSERT INTO `shelves` (`ShelfID`, `ShelfName`) VALUES ('$artShelf', 'Art')";
//       mysqli_query($conn, $artS);
// $scienceS= "INSERT INTO `shelves` (`ShelfID`, `ShelfName`) VALUES ('$scienceShelf', 'Science')";
//       mysqli_query($conn, $scienceS);
// $sportS= "INSERT INTO `shelves` (`ShelfID`, `ShelfName`) VALUES ('$sportShelf', 'Sport')";
//       mysqli_query($conn, $sportS);
// $litS= "INSERT INTO `shelves` (`ShelfID`, `ShelfName`) VALUES ('$litShelf', 'Literature')";
//       mysqli_query($conn, $litS);

//Search for the books.
$searchQ = "SELECT * FROM  `Books`";

//Data from table
$data = mysqli_query($conn,$searchQ);

//Fetching the data
echo "
<table border = 2>
  <tr>
    <th>BookID</th>
    <th>Title</th>
    <th>Author</th>
    <th>Availability</th>
    </tr>
    ";
    while($row = mysqli_fetch_array($data)){
      echo "<tr>";
      echo "<td>".$row['BookID']."</td>";
      echo "<td>".$row['BookTitle']."</td>";
      echo "<td>".$row['Author']."</td>";
      echo "<td>".$row['Availability']."</td>";
      echo "</tr>";
    }
echo "</table>";
echo "<br />";
mysqli_close($conn);
 ?>

<html>
<head>
  <title>Admin View</title>
   <script	src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
</head>

<body>

  <form id = "adminView">
    <input id="addBook" type="button" value ="Add a Book"><br /><br />
      <div id = "add"style="display:none">
        Enter the book title: <input type="text" id="title" placeholder="Book's Title"><br />
        Enter the book author: <input type="text" id="author" placeholder="Book's Author"><br />
        Enter the book genre: <input type="text" id="genre" placeholder="Book's Genre"> (Art, Science, Sport, or Literature)<br />
        <input type="button" id="addTheBook" value="Submit" /><br /><br />
      </div><br />

    <input id="deleteBook" type="button" value = "Delete a book"><br /><br />
      <div id="delete" style="display:none">
        Enter a book ID: <input type="text" id="bookID" placeholder="Book's ID">
        <input type="button" id="remove" value="Remove" /><br />
      </div><br />

    <input id="viewBorrowed" type="button" value = "View borrow history"><br /><br />
    <div id="viewH">
    </div><br />

    <input id="viewShelves" type="button" value = "View all shelves"><br /><br />
    <div id="viewS">
    </div>

  </form>
</body>

<script>
$(document).ready(function(){
  //Add a book
$("#addBook").click(function(){
  $("#add").fadeToggle();
    $("#addTheBook").click(function(){
      $.ajax({
        url: "adminOptions.php",
        type: "POST",
        data: {button:"add", author:$("#author").val(), title:$("#title").val(), genre:$("#genre").val() },
        success: function(e){
          console.log(e);
        }
      });
    });
});//END OF ADD BOOK.

//Delete a book
$("#deleteBook").click(function(){
  $("#delete").fadeToggle();
    $("#remove").click(function(){
      $.ajax({
        url: "adminOptions.php",
        type: "POST",
        data: {button:"delete", bookID:$("#bookID").val()},
        success: function(e){
          console.log(e);
        }
      });
    });
});//END OF DELETE BOOK.

$("#logOut").click(function(){
  $.ajax({
    url: "library.php",
    type:"POST",
    data: {logout: "destroy"},
    success: function(){
      $("#logoutForm").submit();
    }
  });
});//END OF LOGOUT.

$("#viewBorrowed").click(function(){
  $.ajax({
    url: "adminOptions.php",
    type: "POST",
    data: {button:"history"},
    success: function(e){
      $("#viewH").html(e);
      $("#viewH").fadeToggle();
    }
    });
  });//END OF VIEW BORROWED

  $("#viewShelves").click(function(){
    $.ajax({
      url: "adminOptions.php",
      type: "POST",
      data: {button:"shelves"},
      success: function(e){
        $("#viewS").html(e);
        $("#viewS").fadeToggle();
      }
      });
    });

});//END OF DOCUMENT READY.

</script>
<style>
#username {
  position:absolute;
   top:5;
   right:30;
   color: red;
}
#logout{
  position: absolute;
  top: -5;
  right: 30;
  background: #a9014b repeat-x;
  display: inline-block;
  padding: 5px 10px 6px;
  color: #fff;
  text-decoration: none;
  font-weight: bold;
  line-height: 1;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  -moz-box-shadow: 0 1px 3px #999;
  -webkit-box-shadow: 0 1px 3px #999;
  text-shadow: 0 -1px 1px #222;
  border-bottom: 1px solid #222;
  cursor: pointer;
}

</style>
</html>
