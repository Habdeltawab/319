<?php
//Check the Username
function checkUsername($username){
  if(preg_match("/^[a-zA-Z0-9]*$/",$username) && $username !== ""){
    return true;
  }else {
    echo "Username isn't in the correct format<br />";
    return false;
  }
}

//Check Email
function checkEmail($email){
  $value = explode('@',$email);//Split at the @ character

  //Make sure that everything is ok with the formatting.
    if(sizeof($value)==2 && $value[0] !== "" && $value[1] !== ""){
      $value_2 = explode('.', $value[1]);
          if(sizeof($value_2) == 2 && $value_2[0] !== "" && $value_2[1] !== ""){
              if(preg_match("/^[a-zA-Z0-9]*$/", $value[0]) && preg_match("/^[a-zA-Z0-9]*$/", $value_2[0]) && preg_match("/^[a-zA-Z0-9]*$/", $value_2[1])){
                  return true;
                }else{
                  echo "Email isn't in the correct format...<br />";
                }
            }else{
              echo "Please enter email in the correct format i.e. xxx@xxxxx.xxx<br />";
            }
          }else{
            echo "Please enter email in the correct format i.e. xxx@xxxxx.xxx<br />";
          }
        }


//Check Phone Number
function checkPhone($phoneNumber){
  if(preg_match("/^(0|[1-9][0-9]+)$/", $phoneNumber) && $phoneNumber !== ""){
    return true;
  }else{
    echo "Phone number isn's in the correct format .i.e. xxxxxxxxxx<br />";
    return false;
  }
}

//Check First Name
function checkFName($fName){
  if(preg_match("/^[A-z]+$/",$fName) && $fName !== ""){
    return true;
  }else {
    echo "First name isn't in the correct format<br />";
  }
}

//Check Last Name
function checkLName($lName){
  if(preg_match("/^[A-z]+$/",$lName) && $lName !== ""){
    return true;
  }else {
    echo "Last name isn't in the correct format<br />";
  }
}

//Check if the passwords match
function checkPass($pass, $cPass){
  if(strcmp($pass,$cPass) == 0 && $pass !== "" && $cPass !== ""){
    return true;
  }else{
    echo "Passwords don't match<br />";
    echo "Pass: " .$pass. "<br />";
    echo "cPass: " .$cPass. "<br />";
    return false;
  }
}

//Generate a random 3-digit BookID
function generateID(){
$ID = rand(pow(10,2),pow(10,3)-1);
return $ID;
}

//Generate ID for Art books
function ArtID(){
  $ID = generateID();
  while($ID%4 != 0){
    $ID = generateID();
  }
return $ID;
}

//Generate ID for Science books
function scienceID(){
  $ID = generateID();
  while($ID%4 != 1){
    $ID = generateID();
  }
  return $ID;
}

//Generate ID for Sport books
function sportID(){
  $ID = generateID();
  while($ID%4 != 2){
    $ID = generateID();
  }
  return $ID;
}

//Generate ID for Literature books
function literatureID(){
  $ID = generateID();
  while($ID%4 != 3){
    $ID = generateID();
  }
  return $ID;
}

//Check if the user wants to borrow a borrowed book.
function checkIfBorrowed($borrowedBooks, $ID){
  for($j=0; $j < sizeof($borrowedBooks); $j++){//loop through the array.
    if($borrowedBooks[$j] == $ID){//If it is checked out
      return true;
    }
  }
  return false;
}
?>
