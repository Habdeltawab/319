package serverClient;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

//GOALS
// 1. to show client code that connects to the server and sends it a message
//

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.swing.ImageIcon;

public class MyCLient {

	public static void main(String[] args) throws UnknownHostException, IOException {

		Scanner scan = new Scanner(System.in);
		Scanner menu = new Scanner(System.in);
		Scanner adminMenu = new Scanner(System.in);

		String userName = "";// The user's name
		String choice = "";// The user's menu choice

		System.out.print("Please Enter your user name: ");
		userName = scan.nextLine();

		if (userName.toLowerCase().equals("admin")) {
			
			// 2. WRITE A MESSAGE TO THE SOCKET TO SEND TO THE SERVER
			Socket adminSocket = new Socket("localhost", 4444);
			PrintWriter out = new PrintWriter(new BufferedOutputStream(adminSocket.getOutputStream()));
			out.print(userName + "\n");
			out.flush(); // forces data from buffer to be sent to server
			
			Thread adminListener = new Thread(new adminListener(adminSocket));
			adminListener.start();
			

		} else {

			System.out.println("Please choose one of the following options: ");
			System.out.println("1. Send a message to Server.");
			System.out.println("2. Send an Image file to the server.");
			System.out.print("Choice: ");
			choice = menu.nextLine();

			// 1. CONNECT TO THE SERVER AT PORT 4444
			Socket socket = new Socket("localhost", 4444);

			// 2. WRITE A MESSAGE TO THE SOCKET TO SEND TO THE SERVER
			PrintWriter out = new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
			out.print(userName + "\n");
			out.flush(); // forces data from buffer to be sent to server
			
			//What the client wants to do
			if (choice.equals("1")) {
				while (true) {
					System.out.print("Please print something to send to the server: \n  ");
					Thread serverListener = new Thread(new serverHandler(socket));
					serverListener.start();
					String message = userName + ": " + scan.nextLine() + "\n";

					// 2. WRITE A MESSAGE TO THE SOCKET TO SEND TO THE SERVER
					PrintWriter clientSend = new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
					clientSend.print(message + "\n");
					clientSend.flush(); // forces data from buffer to be sent to server
				}
			} if(choice.equals("2")){
				System.out.println("Please choose your image: ");
				Thread imageSender = new Thread(new imageSender(socket));
				imageSender.start();
			}

		}
	}

}

/*
 * This Handles the server
 */
class serverHandler implements Runnable {
	Socket s;
	/* FileWriter writer; */
	int num;

	serverHandler(Socket s) {
		this.s = s;
		/* this.writer = writer; */
	}

	// This is the client handling code
	public void run() {
		Scanner in;

		try {
			// 1. USE THE SOCKET TO READ WHAT THE SERVER IS SENDING
			in = new Scanner(s.getInputStream());

			while (true) {
				String serverMessage = in.nextLine();

				// 2. PRINT WHAT THE SERVER SENT
				System.out.println(" Message from admin " + ": " + serverMessage);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

/*
 * Listens to the server.
 * prompts the admin user with the three options
 */
class adminListener implements Runnable{
	Socket adminSocket;
	adminListener(Socket adminSocket){
		this.adminSocket = adminSocket;
	}


	public void run() {
		Scanner adminScan;
		String adminMenu ="";
		
		try{
			adminScan = new Scanner(adminSocket.getInputStream());
			adminMenu = adminScan.nextLine();
			System.out.println(adminMenu);
			
			Thread choiceSend = new Thread(new choiceSend(adminSocket));
			choiceSend.start();
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
}

/*
 * The admin's choice
 */
class choiceSend implements Runnable{
	Socket adminSocket;
	Scanner in = new Scanner(System.in);
	String choice = "";
	
	choiceSend(Socket adminSocket){
		this.adminSocket = adminSocket;
	}

	public void run() {
		System.out.print("Choice: ");
		try {
			choice = in.nextLine() + "\n";
			
			System.out.println("on the client side you entered: " + choice);
			
			PrintWriter sendChoice = new PrintWriter(adminSocket.getOutputStream()); //Add a bufferedOutputStream ??
			sendChoice.println(choice);
			sendChoice.flush();
			
			Thread sendMessage = new Thread(new sendMessage(adminSocket));
			sendMessage.start();
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
}

/*
 * Send the admin message to the server
 */
class sendMessage implements Runnable{
	Socket adminSocket;
	Scanner adminchoice = new Scanner(System.in);
	String choice = "";
	
	sendMessage(Socket adminSocket){
		this.adminSocket = adminSocket;
	}
	public void run() {
		System.out.println("What is your Message: ");
		choice = adminchoice.nextLine();
		PrintWriter sendMessage;
		
		try {
			sendMessage = new PrintWriter(adminSocket.getOutputStream());
			sendMessage.println(choice);
			sendMessage.flush();
			
			Thread receieveBMessage = new Thread(new receieveBMessage(adminSocket));
			receieveBMessage.start();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}

/*
 * Receive broadcasted message from server
 */
class receieveBMessage implements Runnable{
	Socket adminSocket;
	Scanner bMessage;
	String adminMessage = "";
	
	receieveBMessage(Socket adminSocket){
		this.adminSocket = adminSocket;
	}

	public void run() {
		try {
			bMessage = new Scanner(adminSocket.getInputStream());
			adminMessage = bMessage.nextLine();
			System.out.println("Admin has sent: " + adminMessage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
 class imageSender implements Runnable{
	 Socket imageSocket;
	 
	 imageSender(Socket socket){
		 imageSocket = socket;
	 }
	public void run() {
	/*	try {
			OutputStream outStream = imageSocket.getOutputStream();
			ObjectOutputStream imageOut = new ObjectOutputStream(outStream);
			ImageIcon image = new ImageIcon("D://JAVA//ComS_319//src//Coding is Awesome.jpg");
			imageOut.writeObject(image);
			imageOut.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}*/
	}
	 
 }






