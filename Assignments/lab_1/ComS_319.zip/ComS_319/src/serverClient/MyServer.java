package serverClient;

// GOALS
//
// 1. to show sample Server code
// Note that the server is running on LOCALHOST (which is THIS computer) and the 
// port number associated with this server program is 4444.
// The accept() method just WAITS until some client program tries to access this server
//
// 2. to show how a thread is created to handle client request
//

import java.io.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MyServer {

	public static void main(String[] args) throws IOException {
		/*
		 * An arrayList to hold the client's information
		 */
		ArrayList<Socket> clientInfo = new ArrayList<Socket>();
		ServerSocket serverSocket = null;
		// int clientNum = 0; // keeps track of how many clients were created

		// 1. CREATE A NEW SERVERSOCKET
		try {
			serverSocket = new ServerSocket(4444); // provide MYSERVICE at port
													// 4444
		} catch (IOException e) {
			System.out.println("Could not listen on port: 4444");
			System.exit(-1);
		}

		// 2. LOOP FOREVER - SERVER IS ALWAYS WAITING TO PROVIDE SERVICE!
		while (true) {
			Socket clientConnection = null;
			// Scanner adminUser;

			try {

				// 2.1 WAIT FOR CLIENT TO TRY TO CONNECT TO SERVER
				System.out.println("Waiting for user to connect! \n");
				clientConnection = serverSocket.accept();
				clientInfo.add(clientConnection);// Store client's information
				// adminUser = new Scanner(clientConnection.getInputStream());

				// 2.2 SPAWN A THREAD TO HANDLE CLIENT REQUEST
				System.out.println("Server got connected to a client.");

				Thread clientListener = new Thread(new ClientHandler(clientConnection, clientInfo));
				clientListener.start();

			} catch (IOException e) {
				System.out.println("Accept failed: 4444");
				System.exit(-1);
			}
		}
	}
}

/*
 * Handling client
 */
class ClientHandler implements Runnable {
	Socket client; // this is socket on the server side that connects to the
					// CLIENT
	int lineCount = 0;// To count lines
	ArrayList<Socket> clientInfo = new ArrayList<Socket>();

	ClientHandler(Socket s, ArrayList<Socket> clientInfo) {
		this.client = s;
		this.clientInfo = clientInfo;

	}

	// This is the client handling code
	public void run() {
		Scanner sentUserName;
		String clientUserName = "";// Client's username

		try {
			// 1. USE THE SOCKET TO READ WHAT THE CLIENT IS SENDING
			sentUserName = new Scanner(client.getInputStream());
			clientUserName = sentUserName.nextLine();

			// Is the user inputs admin as user name
			if (clientUserName.toLowerCase().equals("admin")) {

				Thread adminHandler = new Thread(new adminHandler(client, clientInfo));
				adminHandler.start();

			} else {// Take normal messages

				Thread clientMessage = new Thread(new clientMessage(client, clientInfo));
				clientMessage.start();

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

/*
 * Listen for the clients message
 */
class clientMessage implements Runnable {
	Socket client;
	Scanner clientM;
	String theClientMessage = "";
	File chatFile = new File("D://JAVA//ComS_319//src//Chat.txt");
	FileWriter chatWriter;
	ArrayList<Socket> clientInfo = new ArrayList<Socket>();
	ArrayList<String> chatTXT = new ArrayList<String>();
	int lineCount = 0; //Track lines and indexes.

	clientMessage(Socket client, ArrayList<Socket> clientInfo) throws IOException {
		this.client = client;
		FileWriter chatWriter = new FileWriter(chatFile, true);
		this.chatWriter = chatWriter;
		this.clientInfo = clientInfo;
	}

	public void run() {
		
		try {

			while (true) {
				clientM = new Scanner(client.getInputStream());
				theClientMessage = clientM.nextLine();
				chatTXT.add(lineCount + "- " + theClientMessage + ". \n");
				chatWriter.write(chatTXT.get(lineCount).toString() + "\n");
				chatWriter.flush();
				lineCount++;
				System.out.println(theClientMessage); //Printing on the screen.
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

/*
 * Handling admin's credentials
 */
class adminHandler implements Runnable {
	Socket client;
	ArrayList<Socket> clientInfo = new ArrayList<Socket>();

	adminHandler(Socket client_1, ArrayList<Socket> clientInfo) {
		this.client = client_1;
		this.clientInfo = clientInfo;
	}

	public void run() {

		String adminMenu = "Welcome Mr. Admin, What would you like to do? type: (1.Broadcast a message, 2. Open chat history, 3. delete a line from chat history)  ";

		// Send the admin's menu to the client's side
		try {
			PrintWriter send = new PrintWriter(client.getOutputStream());
			send.println(adminMenu);
			send.flush();

			Thread choiceListener = new Thread(new choiceListener(client, clientInfo));
			choiceListener.start();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

/*
 * Listening for the choice from the client
 */
class choiceListener implements Runnable {
	Socket client;
	Scanner input;
	String choice = "";
	ArrayList<Socket> clientInfo = new ArrayList<Socket>();

	choiceListener(Socket client, ArrayList<Socket> clientInfo) {
		this.client = client;
		this.clientInfo = clientInfo;
	}

	public void run() {
		try {
			input = new Scanner(client.getInputStream());
			choice = input.nextLine();
			while (true) {

				// System.out.println("On server side you entered: " + choice);
				// Broadcast the message?????
				if (choice.equals("1")) {
					Thread broadcastMessage = new Thread(new receivedMessage(client, clientInfo));
					broadcastMessage.start();
					break;
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

/*
 * Receiving the message from the admin client
 */
class receivedMessage implements Runnable {
	Socket client;
	ArrayList<Socket> clientInfo = new ArrayList<Socket>();
	String rMessage = "";
	Scanner message;

	receivedMessage(Socket client, ArrayList<Socket> clientInfo) {
		this.client = client;
		this.clientInfo = clientInfo;
	}

	public void run() {
		try {
			message = new Scanner(client.getInputStream());
			rMessage = message.nextLine();

			Thread broadcastMessage = new Thread(new broadcastMessage(client, clientInfo, rMessage));
			broadcastMessage.start();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

/*
 * BroadC=casting the message to all clients
 */
class broadcastMessage implements Runnable {
	Socket client;
	ArrayList<Socket> clientInfo = new ArrayList<Socket>();
	String bMessage = "";
	PrintWriter broadcast;

	broadcastMessage(Socket client, ArrayList<Socket> clientInfo, String bMessage) {
		this.client = client;
		this.clientInfo = clientInfo;
		this.bMessage = bMessage;
	}

	public void run() {
		System.out.println("Message from Admin is: " + bMessage);
		// Broadcasting to all clients
		for (Socket client : clientInfo) {
			try {
				broadcast = new PrintWriter(client.getOutputStream());
				broadcast.println(bMessage);
				broadcast.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
}
