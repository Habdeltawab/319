package lab_1;

import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.io.*;

public class Client implements Runnable {

	private ObjectOutputStream objectOut;
	private String uName;
	private Socket socket;
	
	public static void main(String... args) {
		Client client = new Client();
		new Thread(client).start();
	}

	@Override
	public void run() {
		try {
			socket = new Socket("localhost", 4444);
			objectOut = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));
			new Thread(new serverThread(socket)).start();
		} catch (IOException e) {
			System.out.println("Unable to connect to server: " + e.getMessage());
			System.exit(-1);
		}
		Scanner input = new Scanner(System.in);
		System.out.print("Enter your name: ");
		uName = input.nextLine();
		try {
			objectOut.writeObject(new Message(uName, Message.COMMAND.LOGIN, Message.messageEncoding(uName)));
			objectOut.flush();
		} catch (IOException e) {
			System.out.println("Error sending username to server...");
			System.exit(-1);
		}
		try {
			loopCommands(input);
		} catch (IOException e1) {
			System.out.println("Error sending message to server...");
			System.exit(-1);
		}
	}
	
	private void loopCommands(Scanner userInput) throws IOException {
		Message.COMMAND cmd = Message.COMMAND.LOGIN;
		String message = null;
		commandsList();
		while (cmd != Message.COMMAND.LOGOUT) {
			System.out.print("Enter a command: ");
			cmd = Message.parseC(userInput.nextLine());
			switch (cmd) {
			
			case MSG:
				System.out.print(uName + ": ");
				message = userInput.nextLine();
				objectOut.writeObject(new Message(uName, cmd, Message.messageEncoding(message)));
				objectOut.flush();
				break;
				
			case DELETE_MSG:
				if (adminCheck(uName)) {
					System.out.print("message id to delete: ");
					message = userInput.nextLine();
					objectOut.writeObject(new Message(uName, cmd, Message.messageEncoding(message)));
					objectOut.flush();
				} else
					System.out.println("Invalid Command... Enter '3' to list Commands");
				break;
		
			case TO_ALL:
				if (adminCheck(uName)) {
				System.out.print(uName + ": ");
				message = userInput.nextLine();
				objectOut.writeObject(new Message(uName, cmd, Message.messageEncoding(message)));
				objectOut.flush();
				} else
					System.out.println("Invalid Command... Enter '3' to list Commands");
				break;
				
			case FILE:
				System.out.print("Enter a file path: ");
				Path path = new File(userInput.nextLine()).toPath();
				byte[] fileBytes = Files.readAllBytes(path);
				if (fileBytes.length > 0) {
					Message toServer = new Message(uName, cmd, fileBytes);
					toServer.fileName = path.toString();
					objectOut.writeObject(toServer);
					objectOut.flush();
				} else
					System.out.println("Couldn't find file.");
				break;
				
			case LIST_COMS:
				commandsList();
				break;
				
			case GET_MSGS:
				if (adminCheck(uName)) {
					objectOut.writeObject(new Message(uName, cmd, Message.messageEncoding("")));
					objectOut.flush();
				} else
					System.out.println("Invalid Command... Enter '3' to list Commands");
				break;
				
			case LOGOUT:
				userInput.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Command... Enter '3' to list commands");
				break;
			}
		}
	}
	
	private boolean adminCheck(String username) {
		return username.equals("admin");
	}
	
	private void commandsList() {
		System.out.println("\t0. Send a text message to the server");
		System.out.println("\t1. Send an image file to the server");
		if (uName.equals("admin")) {
			System.out.println("\t2. Broadcast mesage to all clients");
			System.out.println("\t3. List messages");
			System.out.println("\t4. Delete message");
		}
		System.out.println("\t5. List commands");
		System.out.println("\t6. Exit");
	}
	
	private class serverThread implements Runnable {
		
		private Socket socket;
		private ObjectInputStream in;

		private serverThread(Socket socket) throws IOException {
			this.socket = socket;
		}
		
		@Override
		public void run() {
			boolean isRunning = true;
			while (isRunning) {
				try {
					this.in = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
					Message message = (Message) in.readObject();
					System.out.println("");
					echoMessage(message);
					System.out.println("Enter a command: ");
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
					isRunning = false;
				} catch (IOException e) {
					e.printStackTrace();
					isRunning = false;
				}
			}
		}
		
		private void echoMessage(Message msg) {
			System.out.println("[" + msg.uName + "]: " + Message.messageDecoding(msg.message));
		}
		
	}

}