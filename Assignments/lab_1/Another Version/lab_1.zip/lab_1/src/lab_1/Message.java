package lab_1;

import java.io.*;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;

public class Message implements Serializable {

	private static final long serialVersionUID = 1L;

	public String uName;
	public COMMAND cmd;
	public byte[] message;
	public File file;
	public String fileName;

	public enum COMMAND {
		LOGIN, MSG, FILE, TO_ALL, GET_MSGS, DELETE_MSG, LIST_COMS, LOGOUT, NOTHING;
	}

	public Message(String uName, COMMAND cmd, byte[] message) {
		this.uName = uName;
		this.cmd = cmd;
		this.message = message;
	}

	public boolean storeM(int id, String decodedMessage) {
		try {
			FileWriter writer = new FileWriter(new File("chat.txt"), true);
			writer.write("id|" + id + "|username|" + uName + "|data|" + decodedMessage + "\n");
			writer.close();
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	public Message(String username, COMMAND command, File file) {
		this.uName = username;
		this.cmd = command;
		this.file = file;
	}

	public boolean storeF(int id) {
		DateFormat dateF = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'");
		dateF.setTimeZone(TimeZone.getTimeZone("UTC"));
		int i = this.fileName.lastIndexOf('.');
		String extension = "";
		if (i > 0)
			extension = this.fileName.substring(i);
		fileName = uName + "+" + dateF.format(new Date()) + extension;
		storeM(id, fileName);
		try {
			File newFile = new File(fileName);
			newFile.createNewFile();
			Files.write(newFile.toPath(), this.message);
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	public static String getM() {
		String log = "";
		try {
			File ch = new File("chat.txt");
			if (!ch.exists()) {
				ch.createNewFile();
			} else {
				Scanner sc = new Scanner(ch);
				while (sc.hasNextLine()) {
					String line = sc.nextLine();
					log += line + "\n";
				}
				sc.close();
			}

		} catch (IOException e) {

		}
		return log;
	}

	public boolean deleteM(String msgId) {
		try {
			File ch = new File("chat.txt");
			File temp = new File("chatTemp.txt");
			temp.createNewFile();
			if (!ch.exists()) {
				ch.createNewFile();
				return false;
			} else {
				Scanner sc = new Scanner(ch);
				PrintWriter pw = new PrintWriter(temp);
				while (sc.hasNextLine()) {
					String line = sc.nextLine();
					String id = line.split("\\|")[1];
					if (!id.equals(msgId)) {
						pw.write(line + "\n");
						pw.flush();
					}
				}
				sc.close();
				pw.close();
				ch.delete();
				temp.renameTo(ch);
			}

		} catch (IOException e) {
			return false;
		}
		return true;
	}

	public static COMMAND parseC(String code) {
		if (code.matches("[0-9]+")) {
			switch (Integer.parseInt(code)) {
			case 0:
				return COMMAND.MSG;
			case 1:
				return COMMAND.FILE;
			case 2:
				return COMMAND.TO_ALL;
			case 3:
				return COMMAND.GET_MSGS;
			case 4:
				return COMMAND.DELETE_MSG;
			case 5:
				return COMMAND.LIST_COMS;
			case 6:
				return COMMAND.LOGOUT;
			default:
				return COMMAND.LOGIN;
			}
		} else {
			return COMMAND.NOTHING;
		}
	}

	public static int MessageC() {
		try {
			File chat = new File("chat.txt");
			if (!chat.exists()) {
				chat.createNewFile();
				return 0;
			} else {
				Scanner sc = new Scanner(chat);
				int counter = 0;
				while (sc.hasNextLine()) {
					String line = sc.nextLine();
					if (!sc.hasNextLine()) {
						counter = Integer.parseInt(line.split("\\|")[1]);
					}
				}
				sc.close();
				return counter;
			}

		} catch (IOException e) {
			return 0;
		}
	}

	public static String messageDecoding(byte[] msgEncoded) {
		return new String(Base64.getDecoder().decode(msgEncoded));
	}

	public static byte[] messageEncoding(String msg) {
		return Base64.getEncoder().encode(msg.getBytes());
	}

}