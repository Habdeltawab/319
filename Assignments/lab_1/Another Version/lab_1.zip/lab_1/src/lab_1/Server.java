package lab_1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

public class Server implements Runnable {

	private int clientC;
	private ServerSocket sSocket;
	private int messageC;
	ArrayList<WriteClientThread> clientW;
	WriteClientThread admin;

	public static void main(String... args) {
		new Thread(new Server()).start();
	}

	public Server() {
		clientC = 0;
		messageC = Message.MessageC();
		clientW = new ArrayList<WriteClientThread>();
	}

	@Override
	public void run() {
		try {
			sSocket = new ServerSocket(4444);
		} catch (IOException e) {
			printMessage("Server", "Could not start server");
			System.exit(-1);
		}
		while (true) {
			Socket clientSocket = null;
			try {
				printMessage("Server", "Waiting for new client(" + (clientC++) + ")");
				clientSocket = sSocket.accept();
				new Thread(new ReadClientThread(clientSocket), "readClient" + clientC).start();
			} catch (IOException e) {
				printMessage("Server", "Could not connect client(" + clientC + ")");
				System.exit(-1);
			}
		}
	}

	private void printMessage(String name, String msg) {
		System.out.println("[" + name + "]: " + msg);
	}

	private class ReadClientThread implements Runnable {

		private String uName;
		private ObjectInputStream objectIn;
		private boolean running;
		private Socket socket;

		private ReadClientThread(final Socket socket) {
			this.socket = socket;
		}

		@Override
		public void run() {
			try {
				objectIn = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
				uName = ((Message) objectIn.readObject()).uName;
				printMessage("Server", uName + " connected");
				clientW.add(new WriteClientThread(socket));
				if (uName.equals("admin")) {
					admin = new WriteClientThread(socket);
				}
			} catch (IOException e) {
				printMessage("Server", "Could not get input stream from " + uName);
			} catch (ClassNotFoundException e) {
				printMessage("Server", "Could not understand data from " + uName);
			}
			running = true;
			while (running) {
				try {
					handleMessage((Message) objectIn.readObject());
				} catch (SocketException e) {
					printMessage("Server", uName + " disconnected");
					running = false;
				} catch (ClassNotFoundException e) {
					printMessage("Server", "Could not understand data from " + uName);
					running = false;
				} catch (IOException e) {
					printMessage("Server", uName + " disconnected");
					running = false;
				}
			}
		}

		private void handleMessage(Message message) {
			String decodedMessage = "";
			switch (message.cmd) {
			case FILE:
				message.storeF(messageC++);
				printMessage(uName, message.fileName);
				break;
			case GET_MSGS:
				String chatLog = Message.getM();
				sendAdmin(chatLog);
				printMessage("Server", uName + " got messages");
				break;
			case MSG:
				decodedMessage = Message.messageDecoding(message.message);
				message.storeM(messageC++, Message.messageDecoding(message.message));
				printMessage(uName, Message.messageDecoding(message.message));
				break;
			case DELETE_MSG:
				decodedMessage = Message.messageDecoding(message.message);
				message.deleteM(decodedMessage);
				printMessage("Server", uName + " deleted message " + decodedMessage);
				break;
			case TO_ALL:
				decodedMessage = Message.messageDecoding(message.message);
				message.storeM(messageC++, decodedMessage);
				sendToClients(message.message);
				printMessage(uName, decodedMessage);
				break;
			case LIST_COMS:
			case LOGIN:
			case LOGOUT:
			default:
				printMessage("Server", uName + "sent a bad request");
				break;
			}
		}

		private void sendToClients(byte[] msg) {
			Thread clients[] = new Thread[Thread.activeCount()];
			Thread.enumerate(clients);
			for (WriteClientThread thread : clientW) {
				thread.userMessage = uName;
				thread.message = msg;
				new Thread(thread).start();
			}
		}

		private void sendAdmin(String chatLog) {
			admin.userMessage = "Chat Log";
			admin.message = Message.messageEncoding(chatLog);
			new Thread(admin).start();
		}

	}

	private class WriteClientThread implements Runnable {

		private ObjectOutputStream out;
		private Socket socket;
		public byte[] message;
		public String userMessage;

		private WriteClientThread(Socket socket) {
			this.socket = socket;
		}

		@Override
		public void run() {
			try {
				out = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));
				out.writeObject(new Message(userMessage, Message.COMMAND.MSG, message));
				out.flush();
			} catch (IOException e) {
				System.out.println("Cannot start WriteClientThread");
			}
		}

	}

}