<?php

$path = 'phpseclib';
	set_include_path(get_include_path() . PATH_SEPARATOR . $path);
	include_once('Crypt/RSA.php');

$user = $_POST['userName'];
$pass = $_POST['pass'];

$users = json_decode(file_get_contents("users.txt"));

for($i = 0; $i < sizeof($users); $i++) {

	if(rsa_decrypt(base64_decode($users[$i]->user), json_decode($users[$i]->pvky)) === $user && rsa_decrypt(base64_decode($users[$i]->$pass), json_decode($users[$i]->pvky)) === $pass) {

		echo json_decode("true");

	}

}

function rsa_decrypt($string, $private_key)
{
    $cipher = new Crypt_RSA();
    $cipher->loadKey($private_key);
    $cipher->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
    return $cipher->decrypt($string);
}

?>
