<?php

// Begin session with username
session_start();
$_SESSION = Array(

	"user" => $_POST['user']

);

// Retrieve file contents
$file = file_get_contents("posts.txt");
function createTable($table) {

	// Turn into JSON object
	$arr = json_decode($table);
	$temp = "";

	// Retrieve all values from file
	// Piece together our html table from the file contents
	for($i = 0; $i < sizeof($arr); $i++) {

		$temp .= "<tr class=".$arr[$i]->userID." id="."'".$arr[$i]->userID.str_replace(array("'", " "), '',$arr[$i]->postTitle)."'".">";
			$temp .= "<td>".$arr[$i]->postTitle."</td>";
			$temp .= "<td>".$arr[$i]->postID."</td>";
			$temp .= "<td>".$arr[$i]->postTime."</td>";
		$temp .= "</tr>";

	}
	return $temp;

}

?>
<!DOCTYPE html>
<html>
<head>
	<title>viewPosts</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</head>
<body>

<table id="myTable" border="2">
	<tr id="headers">
		<th>Title</th>
		<th>Description</th>
		<th>Time</th>
	</tr>
	<?php echo createTable($file);?>
</table>

<input id="uButton" type="button" value="Update Posts"><br>
<!-- This is our send message button -->
<input id="send"	type="button" value="Send Message"><br>
<!-- This button will redirect user to their inbox -->
<form method="POST" action="inbox.php">
	<input type='hidden' name='user' value='<?php echo $_SESSION['user'];?>'>
	<input type='submit' value="Inbox">
</form>
<form id="lout" action="login.php">
	<input id="logout" type='button' value="Logout">
</form>
<div id="confirm"></div>
<div id="update"></div>
<div id="sendm"></div>
</body>

<script>

	$(document).ready(function() {

		// Update posts on click handler
		$("#uButton").click(function() {
			if('<?php echo $_SESSION['user'];?>' != "admin")  {
				$("#update").html("<br><form id='temp'>Title: <input id='title' type='text'><br>Message: <input id='message' type='text'><br><input id='subButton' type='button' value='Submit'></form>");
				$("#subButton").click(function() {
					$.ajax({}
						url : 'updatePosts.php',
				    	type : 'POST',
				    	data : {userID : "<?php echo $_SESSION['user'];?>",
				        	    postID : $("#message").val(),
				       		 	postTitle : $("#title").val(),
				       		 	postTime   : Date()},
				    	success : function(output) {

				    		if(output == 1) {

					    		var oldEntry = "#";
					    		oldEntry += "<?php echo $_SESSION['user'];?>";
					    		oldEntry += $("#title").val().replace(/[\s']/g, '');
					    		oldEntry = (oldEntry + ' :nth-child(2)');
					    		$(oldEntry).text($("#message").val());
					    	} else {

					    		var newEntry = "<tr class='<?php echo $_SESSION['user'];?>' id=";
				    			newEntry += "<?php echo $_SESSION['user'];?>";
				    			newEntry += $("#title").val().replace(/[\s']/g, '');
				    			newEntry += ">";
					    		newEntry += "<td>"+$("#title").val()+"</td>";
					    		newEntry += "<td>"+$("#message").val()+"</td>";
					    		newEntry += "<td>"+Date()+"</td>";
				    			newEntry += "</tr>";
				    			$(newEntry).insertAfter("#headers");

				    		}
				    		$("#update").empty();
				    		$(".<?php echo $_SESSION['user'];?> :nth-child(2)").dblclick(function() {

								$(this).html("<form id='clickForm'><input id='tempInput' type='text' value='"+$(this).text()+"'></form>");

									$("#clickForm").submit(function(e) {

										e.preventDefault();
										var temp = $("#tempInput").val();
										$(this).html(temp);
										var tempTitle = ($($(this).parent().parent().html()).html());

									$.ajax({

										url : 'updatePosts.php',
										type : 'POST',
										data : {userID : '<?php echo $_SESSION['user'];?>',
												postID : temp,
												postTitle : tempTitle,
												postTime : Date()}

									});

								});

							});

				    	}

					});

				});

			} else {

				$("#update").html("<br><form id='adminForm'>User : <input id='user' type='text'><br>Title of message to delete:<br><input id='title' type='text'><br><input id='subButton' type='button' value='Delete'></form>");

				$("#subButton").click(function (){
					$.ajax({

						url : 'updatePosts.php',
						type : 'POST',
						data : {admin : 'admin',
								user  : $("#user").val(),
								title : $("#title").val()},
						success : function(output) {

							// Select element to delete
							$('#'+$("#user").val()+$("#title").val().replace(/[\s']/g, '')).remove();
							$("#update").empty();

						}

					});

				});

			}

		});

		$("#send").click(function() {
			$("#sendm").html("<br><form id='sendForm'>TO: <input id='receiver' type='text'><br>MESSAGE: <input id='content' type='text'><br><input id='sendSubmit' type='button' value='Send'>");
			$("#sendSubmit").click(function() {
				$("confirm").html("");
				$.ajax({

					url : 'sendMessage.php',
					type : 'POST',
					data : {to : $("#receiver").val(),
							from : '<?php echo $_SESSION['user'];?>',
							message : $("#content").val()},
					success : function(output) {

						if(output == 1) {

							$("#confirm").html("Message Sent Succesfully.");

						} else {

							$("#confirm").html("Invalid Recipient.")

						}
						$("#sendm").empty();

					}

				});

			});

		});

		$("#logout").click(function() {

			$.ajax({

				url : 'logout.php',
				success : function(output) {

					$("#lout").submit();

				}

			});

		});

		$(".<?php echo $_SESSION['user'];?> :nth-child(2)").dblclick(function() {

			$(this).html("<form id='clickForm'><input id='tempInput' type='text' value='"+$(this).text()+"'></form>");

			$("#clickForm").submit(function(e) {

				e.preventDefault();
				var temp = $("#tempInput").val();
				$(this).html(temp);
				var tempTitle = ($($(this).parent().parent().html()).html());

				$.ajax({

					url : 'updatePosts.php',
					type : 'POST',
					data : {userID : '<?php echo $_SESSION['user'];?>',
							postID : temp,
							postTitle : tempTitle,
							postTime : Date()}

				});

			});

		});

	});

</script>
</html>
