<?php
$path = 'phpseclib';
	set_include_path(get_include_path() . PATH_SEPARATOR . $path);
	include_once('Crypt/RSA.php');

$rsa = new Crypt_RSA();
$rsa->setPrivateKeyFormat(CRYPT_RSA_PRIVATE_FORMAT_PKCS1);
$rsa->setPublicKeyFormat(CRYPT_RSA_PUBLIC_FORMAT_PKCS1);
extract($rsa->createKey(1024));
$flag = 1;
$json = Array();
$json = generateNewJsonObject($json, $publickey, $privatekey);


$file = json_decode(file_get_contents("users.txt"));
$newFile = Array();

if(sizeof($file[0]) === 0 || $file === "") {

	array_push($newFile, $json);
	file_put_contents("users.txt", json_encode($newFile));
	echo $flag;

} else if(isset($json['user']) && isset($json['pswd'])) {

	$flag = 1;
	for($i = 0; $i < sizeof($file); $i++) {


		if(rsa_decrypt(base64_decode($file[$i]->user), json_decode($file[$i]->pvky)) === rsa_decrypt(base64_decode($json['user']),json_decode($json['pvky']))) {

			$flag = 0;

		}
		array_push($newFile, $file[$i]);

	}
	if($flag == 1) {

		array_push($newFile, $json);

	}
	file_put_contents("users.txt", json_encode($newFile));

	echo $flag;

}
function generateNewJsonObject($obj, $pkey, $pvky) {

	if((isset($_POST['user']) && isset($_POST['pswd']))) {

		if($_POST['user'] != "" && $_POST['pswd'] != "") {
			$obj['user'] = json_encode(base64_encode(rsa_encrypt($_POST['user'], $pkey)));
			$obj['pswd'] = json_encode(base64_encode(rsa_encrypt($_POST['pswd'], $pkey)));
			$obj['pkey'] = json_encode($pkey);
			$obj['pvky'] = json_encode($pvky);

		}

 	}
 	return $obj;

}

function rsa_encrypt($string, $public_key) {
    $cipher = new Crypt_RSA();
    $cipher->loadKey($public_key);
    $cipher->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
    return $cipher->encrypt($string);
}

function rsa_decrypt($string, $private_key)
{
    $cipher = new Crypt_RSA();
    $cipher->loadKey($private_key);
    $cipher->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
    return $cipher->decrypt($string);
}
?>
