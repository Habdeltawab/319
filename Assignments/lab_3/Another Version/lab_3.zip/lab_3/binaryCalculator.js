var binCalc = {

	Model : {

		oldVal : undefined,
		operand: undefined,
		memory : 0

	},

	View : {

		textRow2 : {id: "textRow2", type: "text", value: "", onclick:""},
		button0 : {id: "button0", type: "button", value: 0, onclick:""},
  		button1 : {id: "button1", type: "button", value: 1, onclick:""},
  		buttonAdd :            {id: "buttonAdd", type: "button", value: "+", onclick:""},
  		buttonEquals :         {id: "buttonEquals", type: "button", value: "=", onclick:""},
  		buttonSubtraction :    {id: "buttonSubtraction", type: "button", value: "-", onclick:""},
  		buttonMultiplication : {id: "buttonMultiplication", type: "button", value: "*", onclick:""},
  		buttonDivision :       {id: "buttonDivision", type: "button", value: "\/", onclick:""},
  		buttonClear :          {id: "buttonClear", type: "button", value: "C", onclick:""},
  		buttonMPlus :          {id: "buttonMPlus", type: "button", value: "M+", onclick:""},
  		buttonMMinus :         {id: "buttonMMinus", type: "button", value: "M-", onclick:""},
  		buttonMClear :         {id: "buttonMClear", type: "button", value: "MC", onclick:""},
  		buttonMReveal :        {id: "buttonMReveal", type: "button", value: "MR", onclick:""},
  		buttonNot : 		   {id: "buttonNot", type: "button", value: "\~", onclick:""},
  		buttonMod : 		   {id: "buttonMod", type: "button", value: "\%", onclick:""},
  		buttonLShift : 		   {id: "buttonLShift", type: "button", value: "\<\<", onclick:""},
  		buttonRShift : 		   {id: "buttonRShift", type: "button", value: "\>\>", onclick:""},
  		buttonAND    :         {id: "buttonAND", type: "button", value: "\&", onclick:""},
  		buttonOR     : 		   {id: "buttonOR", type: "button", value: "\|", onclick:""}

	},

	Controller : {


	},

	run : function() {

		binCalc.attachHandlers();
		console.log(binCalc.display());
		return binCalc.display();

	},

	displayElement : function (element) {

 	 	var s = "<input ";
  		s += " id=\"" + element.id + "\"";
  		s += " type=\"" + element.type + "\"";
  		s += " value= \"" + element.value + "\"";
  		s += " onclick= \"" + element.onclick + "\"";
  		s += ">";
  		return s;

	},

	display : function() {

		var s;
		s =  "<table id=\"myTable\" border = 2>";
		s += "<tr><td>" + binCalc.displayElement(binCalc.View.textRow2) + "</td></tr>";
		s += "<tr><td>";
		s += binCalc.displayElement(binCalc.View.button1);
		s += binCalc.displayElement(binCalc.View.button0);
		s += binCalc.displayElement(binCalc.View.buttonNot);
		s += "</tr></td>";
		s += "<tr><td>";
		s += binCalc.displayElement(binCalc.View.buttonAdd);
		s += binCalc.displayElement(binCalc.View.buttonMod);
		s += binCalc.displayElement(binCalc.View.buttonLShift);
		s += "</tr></td>";
		s += "<tr><td>";
		s += binCalc.displayElement(binCalc.View.buttonRShift);
		s += binCalc.displayElement(binCalc.View.buttonSubtraction);
		s += binCalc.displayElement(binCalc.View.buttonAND);
		s += "</tr></td>";
		s += "<tr><td>";
		s += binCalc.displayElement(binCalc.View.buttonOR);
		s += binCalc.displayElement(binCalc.View.buttonMultiplication);
		s += binCalc.displayElement(binCalc.View.buttonDivision);
		s += "</tr></td>";
		s += "<tr><td>";
		s += binCalc.displayElement(binCalc.View.buttonMReveal);
		s += binCalc.displayElement(binCalc.View.buttonMMinus);
		s += binCalc.displayElement(binCalc.View.buttonMPlus);
		s += "</tr></td>";
		s += "<tr><td>";
		s += binCalc.displayElement(binCalc.View.buttonClear);
		s += binCalc.displayElement(binCalc.View.buttonMClear);
		s += binCalc.displayElement(binCalc.View.buttonEquals);
		s += "</tr></td>";
		s += "</table>";
		return s;

	},

	attachHandlers : function() {

		binCalc.View.button0.onclick = "binCalc.button0Handler()";
		binCalc.View.button1.onclick = "binCalc.button1Handler()";
		binCalc.View.buttonAdd.onclick = "binCalc.buttonAdditionHandler()";
		binCalc.View.buttonEquals.onclick = "binCalc.buttonEqualsHandler()";
		binCalc.View.buttonNot.onclick = "binCalc.buttonNotHandler()";
		binCalc.View.buttonMod.onclick = "binCalc.buttonModHandler()";
		binCalc.View.buttonLShift.onclick = "binCalc.buttonLShiftHandler()";
		binCalc.View.buttonRShift.onclick = "binCalc.buttonRShiftHandler()";
		binCalc.View.buttonSubtraction.onclick = "binCalc.buttonSubtractionHandler()";
		binCalc.View.buttonAND.onclick = "binCalc.buttonANDHAndler()";
		binCalc.View.buttonOR.onclick = "binCalc.buttonORHandler()";
		binCalc.View.buttonMultiplication.onclick = "binCalc.buttonMultiplicationHandler()";
		binCalc.View.buttonDivision.onclick = "binCalc.buttonDivisionHandler()";
		binCalc.View.buttonClear.onclick = "binCalc.buttonClearHandler()";
		binCalc.View.buttonMReveal.onclick = "binCalc.buttonMRevealHandler()";
		binCalc.View.buttonMPlus.onclick = "binCalc.buttonMPlusHandler()";
		binCalc.View.buttonMMinus.onclick = "binCalc.buttonMMinusHandler()";
		binCalc.View.buttonMClear.onclick = "binCalc.buttonMClearHandler()";
		binCalc.View.buttonMReveal.onclick = "binCalc.buttonMRevealHandler()";

	},

	buttonMClearHandler : function() {

		binCalc.Model.memory = 0;

	},

	buttonMMinusHandler : function() {

		binCalc.Model.memory -= binCalc.binaryToDecimal(document.getElementById("textRow2").value);

	},

	buttonMPlusHandler : function() {

		binCalc.Model.memory += binCalc.binaryToDecimal(document.getElementById("textRow2").value);

	},

	buttonMRevealHandler : function() {

		document.getElementById("textRow2").value = binCalc.decimalToBinary(binCalc.Model.memory);

	},

	buttonClearHandler : function() {

		document.getElementById("textRow2").value = "";

	},

	buttonDivisionHandler : function() {

		binCalc.Model.oldVal = binCalc.binaryToDecimal(document.getElementById("textRow2").value);
		binCalc.Model.operand = "/";
		document.getElementById("textRow2").value = "";

	},

	buttonMultiplicationHandler : function() {

		binCalc.Model.oldVal = binCalc.binaryToDecimal(document.getElementById("textRow2").value);
		binCalc.Model.operand = "*";
		document.getElementById("textRow2").value = "";

	},

	buttonORHandler : function() {

		binCalc.Model.oldVal = binCalc.binaryToDecimal(document.getElementById("textRow2").value);
		binCalc.Model.operand = "|";
		document.getElementById("textRow2").value = "";

	},

	buttonANDHAndler : function() {

		binCalc.Model.oldVal = binCalc.binaryToDecimal(document.getElementById("textRow2").value);
		binCalc.Model.operand = "&";
		document.getElementById("textRow2").value = "";

	},

	buttonSubtractionHandler : function() {

		binCalc.Model.oldVal = binCalc.binaryToDecimal(document.getElementById("textRow2").value);
		binCalc.Model.operand = "-";
		document.getElementById("textRow2").value = "";

	},

	buttonLShiftHandler : function() {

		document.getElementById("textRow2").value += 0;

	},

	buttonRShiftHandler : function() {

		document.getElementById("textRow2").value = "0" + document.getElementById("textRow2").value;

	},

	buttonModHandler : function() {

		binCalc.Model.oldVal = binCalc.binaryToDecimal(document.getElementById("textRow2").value);
		binCalc.Model.operand = "%";
		document.getElementById("textRow2").value = "";

	},

	buttonNotHandler : function() {

		var arr = [];
		var temp = document.getElementById("textRow2").value;
		temp += "";

		for(var i = 0; i < temp.length; i++) {

			arr.push(temp[i]);

		}

		for(var i = 0; i < arr.length; i++) {

			if(arr[i] == 0) {

				arr[i] = 1;

			} else {

				arr[i] = 0;

			}

		}

		temp = "";

		for(var i = 0; i < arr.length; i++) {

			temp += arr[i];

		}

		document.getElementById("textRow2").value = temp;

	},

	buttonEqualsHandler : function() {

		if(binCalc.Model.operand == "+") {

			document.getElementById("textRow2").value = binCalc.decimalToBinary(binCalc.binaryToDecimal(document.getElementById("textRow2").value) + binCalc.Model.oldVal);

		} else if(binCalc.Model.operand == "%") {

			document.getElementById("textRow2").value = binCalc.decimalToBinary(binCalc.Model.oldVal % binCalc.binaryToDecimal(document.getElementById("textRow2").value));

		} else if(binCalc.Model.operand == "-") {

			document.getElementById("textRow2").value = binCalc.decimalToBinary(binCalc.Model.oldVal - binCalc.binaryToDecimal(document.getElementById("textRow2").value));

		} else if(binCalc.Model.operand == "&") {

			document.getElementById("textRow2").value = binCalc.decimalToBinary((binCalc.Model.oldVal) & (binCalc.binaryToDecimal(document.getElementById("textRow2").value)));

		} else if(binCalc.Model.operand == "|") {

			document.getElementById("textRow2").value = binCalc.decimalToBinary((binCalc.Model.oldVal) | (binCalc.binaryToDecimal(document.getElementById("textRow2").value)));

		} else if(binCalc.Model.operand == "*") {

			document.getElementById("textRow2").value = binCalc.decimalToBinary((binCalc.Model.oldVal) * (binCalc.binaryToDecimal(document.getElementById("textRow2").value)));

		} else if(binCalc.Model.operand == "/") {

			document.getElementById("textRow2").value = binCalc.decimalToBinary((binCalc.Model.oldVal) / (binCalc.binaryToDecimal(document.getElementById("textRow2").value)));

		}

		binCalc.Model.oldVal = undefined;
		binCalc.Model.operand = undefined;

	},

	button0Handler : function() {

		document.getElementById("textRow2").value += 0;

	},

	button1Handler : function() {

		document.getElementById("textRow2").value += 1;

	},

	buttonAdditionHandler : function() {

		binCalc.Model.oldVal  = binCalc.binaryToDecimal(document.getElementById("textRow2").value);
		binCalc.Model.operand = "+";
		document.getElementById("textRow2").value = "";

	},

	binaryToDecimal : function(value) {

		value += "";
		var ret = 0;
		var arr = [];
		for (var i = 0; i < value.length; i++) {

			arr.push(value.charAt(i));

		}

		for(var i = 0; i < arr.length; i++) {

			ret += ((Math.pow(2,arr.length - i - 1)) * arr[i]);

		}

		return ret;

	},

	decimalToBinary : function(value) {

		var arr = [];
		while(parseInt(value) != 0) {

			arr.push(value % 2);
			value = parseInt(value / 2);

		}
		arr.reverse();
		value = "";
		for (var i = 0; i < arr.length; i++) {
			value += arr[i];
		}
		return value;

	}
}
