$('#submit').click(function() {
  var inputs = $('form').find('input, select');
  var successes = 0;
  for (i = 0; i < inputs.length; i++) {
    if ($(inputs[i]).val() == '') {
      addDanger(inputs[i]);
    } else if (inputs[i].name == 'fName') {
      console.log('matching email...');
      console.log(/^[\w\d]+$/.test($(inputs[i]).val()));
      if (/^[\w\d]+$/.test($(inputs[i]).val())) {
        addSuccess(inputs[i]);
        successes++;
      } else {
        addDanger(inputs[i]);
      }
    } else if (inputs[i].name == 'lName') {
      console.log('matching phone...');
      console.log(/^[\w\d]+$/.test($(inputs[i]).val()));
      if (/^[\w\d]+$/.test($(inputs[i]).val())) {
        addSuccess(inputs[i]);
        successes++;
      } else {
        addDanger(inputs[i]);
      }
    } else if (inputs[i].name == 'gender') {
      console.log('matching gender...');
      console.log(/^(Male)|(Female)$/.test($(inputs[i]).val()));
      if (/^(Male)|(Female)$/.test($(inputs[i]).val())) {
        addSuccess(inputs[i]);
        successes++;
      } else {
        addDanger(inputs[i]);
      }
    } else if (inputs[i].name == 'state') {
      console.log('matching state...');
      console.log(/\w+/.test($(inputs[i]).val()));
      if (/\w+/.test($(inputs[i]).val())) {
        addSuccess(inputs[i]);
        successes++;
      } else {
        addDanger(inputs[i]);
      }
    }
  }
  if (successes == inputs.length) {
    window.location = 'validation2.html';
  }
});
