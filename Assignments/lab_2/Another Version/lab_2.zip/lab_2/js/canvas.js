var canvas = $("canvas")[0],
    ctx = canvas.getContext("2d"),
    x = 5,
    y = 125,
    dir = 0,
    running = false,
    left = $('#left'),
    right = $('#right'),
    toggle = $('#toggle'),
    reset = $('#reset');

ctx.fillStyle="#FF0000";
ctx.fillRect(x,y,5,5);

left.click(function() {
  changeDir(1);
});

right.click(function() {
  changeDir(0);
});

toggle.click(function() {
  if (toggle.html() == 'Start') {
    toggle.html('Stop');
    toggle.removeClass('btn-primary');
    toggle.addClass('btn-danger');
  } else {
    toggle.removeClass('btn-danger');
    toggle.addClass('btn-primary');
    toggle.html('Start');
  }
  running = !running;
});

reset.click(function() {
  if (toggle.html() == 'Stop') {
    toggle.click();
  }
  x = 5;
  y = 125;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillRect(x,y,5,5);
});

function changeDir(change) {
  if (change == 0) {
    if (dir == 0) dir = 3;
    else dir--;
  } else {
    if (dir == 3) dir = 0;
    else dir++;
  }
}

function move() {
  switch (dir) {
    case 0:
      x += 5;
      break;
    case 1:
      y -= 5;
      break;
    case 2:
      x -= 5;
      break;
    default:
      y += 5;
      break;
  }
  ctx.fillRect(x, y, 5, 5);
}

timer = setInterval(function() {
  if (running) move();
}, 1000);
