$('#submit').click(function() {
  var inputs = $('form').find('input');
  var successes = 0;
  for (i = 0; i < inputs.length; i++) {
    if ($(inputs[i]).val() == '') {
      addDanger(inputs[i]);
    } else if (inputs[i].name == 'email') {
      console.log('matching email...');
      console.log(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test($(inputs[i]).val()));
      if (/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test($(inputs[i]).val())) {
        addSuccess(inputs[i]);
        successes++;
      } else {
        addDanger(inputs[i]);
      }
    } else if (inputs[i].name == 'phone') {
      console.log('matching phone...');
      console.log(/^\d{3}[-.]?\d{3}[-.]?\d{4}$/.test($(inputs[i]).val()));
      if (/^\d{3}[-.]?\d{3}[-.]?\d{4}$/.test($(inputs[i]).val())) {
        addSuccess(inputs[i]);
        successes++;
      } else {
        addDanger(inputs[i]);
      }
    } else if (inputs[i].name == 'address') {
      console.log('matching address...');
      console.log(/^[A-Za-z ]+,[ ]?[A-Za-z]{2,}$/.test($(inputs[i]).val()));
      if (/^[A-Za-z ]+,[ ]?[A-Za-z ]{2,}$/.test($(inputs[i]).val())) {
        addSuccess(inputs[i]);
        successes++;
      } else {
        addDanger(inputs[i]);
      }
    }
  }
  if (successes == inputs.length) {
    if (typeof(Storage) !== "undefined") {
      localStorage.setItem('address', $(inputs[2]).val());
      console.log(localStorage.getItem('address'));
    } else {
      console.log('No local storage!');
    }
    window.location = 'map.html';
  }
});
