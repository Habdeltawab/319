var wrong = $('<img src="res/wrong.png" width="20px" height="20px"/>');
function addDanger(el) {
  var obj = $(el);
  obj.removeClass('form-control-success');
  obj.addClass('form-control-danger');
  obj.parent('div').removeClass('has-success');
  obj.parent('div').addClass('has-error');
  if (obj.prev().is('label')) {
    wrong.clone().insertAfter(obj.prev());
  } else {
    obj.prev().replaceWith(wrong.clone());
  }
}

var right = $('<img src="res/correct.png" width="20px" height="20px"/>');
function addSuccess(el) {
  var obj = $(el);
  obj.removeClass('form-control-danger');
  obj.addClass('form-control-success');
  obj.parent('div').removeClass('has-error');
  obj.parent('div').addClass('has-success');
  if (obj.prev().is('label')) {
    right.clone().insertAfter(obj.prev());
  } else {
    obj.prev().replaceWith(right.clone());
  }
}

function removeInfo(el) {
  var obj = $(el);
  obj.removeClass('form-control-success').removeClass('form-control-danger');
  obj.parent('div').removeClass('has-success').removeClass('has-error');
  obj.parent('div').find('img').remove();
}

$('#cancel').click(function() {
  form = $('form');
  if (form != null) {
    form[0].reset();
    inputs = form.find('input');
    for (var i = 0; i < inputs.length; i++) {
      removeInfo(inputs[i]);
    }
  }
});
