google.charts.load('upcoming', {'packages': ['geomap']});

google.charts.setOnLoadCallback(drawMap);

function drawMap() {
  var data = google.visualization.arrayToDataTable([
    ['City', '', 'Name'],
    [localStorage.getItem('address').split(',')[0], null, 'You are here']
  ]);

  var options = {};
  options['region'] = 'US';
  options['colors'] = [0xFF8747, 0xFFB581, 0xc06000]; //orange colors
  options['dataMode'] = 'markers';
  var container = $('#map_canvas')[0];
  var geomap = new google.visualization.GeoMap(container);
  geomap.draw(data, options);
};
