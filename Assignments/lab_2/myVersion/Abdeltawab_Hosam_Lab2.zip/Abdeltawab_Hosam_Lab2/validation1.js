


//Checks for validity
function checkEverything() {
	var fName = document.forms["validationForm"]["firstName"].value;//gets the value of the first name.
	firstNameCheck(fName);//pass the first name.
	
	var lName = document.forms["validationForm"]["lastName"].value;//gets the value of the last name.
	lastNameCheck(lName);//pass in the last name.
	
	var state = document.forms["validationForm"]["state"].value;//Gets the value of the state.
	saveState(state);//passes the value of the state.
	
	var fName = document.forms["validationForm"]["firstName"].value;
	
	
	var lName = document.forms["validationForm"]["lastName"].value;
	saveLastName(lName);
	
	var gender = document.forms["validationForm"]["gender"].value;
	saveGender(gender);
	
	var firstOK = firstNameCheck(fName);//Returns TRUE if first name checks.
	var lastOK =  lastNameCheck(lName); //Returns False if last name checks.
	
	saveFirstName(firstOK);
	saveLastName(lastOK);
	
	
	nextPage(firstOK, lastOK);//Goes to the next page after everything is verified
	
}

//Goes to the next page if everything is verified.
function nextPage(first, second){
	if(first == true && second == true){
	window.location.href = "validation2.html";
	}
}

//Save the first name into a local storage.
function saveFirstName(fName){
	if(fName == true){
	localStorage.setItem("first", fName);//save the value state to a local variable with the name reference first.
	}
}
//Save the last name into a local storage.
function saveLastName(lName){
	if(lName == true){
	localStorage.setItem("last", lName);//save the value state to a local variable with the name reference last.
	}
}
//Save the state into a local storage.
function saveGender(gender){
	localStorage.setItem("gender", gender);//save the value state to a local variable with the name reference gender.
	
}
//Save the state into a local storage.
function saveState(state){
	localStorage.setItem("State", state);//save the value state to a local variable with the name reference State.
	
}

//Checks first name validity
function firstNameCheck(firstName){
	if(firstName == ""){
		var wrong = getImage(false, "firstName");
		document.getElementById("FirstName").appendChild(wrong);
		alert("First Name field must be filled out.");
	}else {
		var check = alphaNumCheck(firstName);
		if(!check){	
		  var wrong = getImage(false, "firstName");
		  document.getElementById("FirstName").appendChild(wrong);
		  alert("First name should be alphaNumeric.");
		  return false;
			
		}else{
			var correct = getImage(true, "firstName");
			document.getElementById("FirstName").appendChild(correct);
			return true;
			
		}
	}
}

//Checks for last name validity
function lastNameCheck(lastName){
	if(lastName == ""){
		  var wrong = getImage(false, "lastName");
		  document.getElementById("LastName").appendChild(wrong);
		alert("Last Name field must be filled out.");
	}else {
		var check = alphaNumCheck(lastName);
		if(!check){	
		  var wrong = getImage(false, "lastName");
		  document.getElementById("LastName").appendChild(wrong);
		  alert("Last name name should be alphaNumeric.");
		  return false;
			
		}else{
			var correct = getImage(true, "lastName");
			document.getElementById("LastName").appendChild(correct);
			return true;
			
		}
	}
}


//Checks if alphanumeric 
function alphaNumCheck(entry) {
    let regex = /^[a-z0-9]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}

//Image printing, correct or wrong.
function getImage(bool, ID) {
    var image = document.getElementById("image" + ID);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + ID;
    }
    image.src = bool ? './correct.png' : './wrong.png';
    return image;
}




