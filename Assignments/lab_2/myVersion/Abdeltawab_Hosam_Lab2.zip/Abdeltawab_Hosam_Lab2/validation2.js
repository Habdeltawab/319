function validate() {
	
    var email = document.forms["contact information"]["email"].value;
	emailCheck(email);
	saveEmail(email);
	
	var phone = document.forms["contact information"]["phone"].value;//The phone value
	phoneCheck(phone); //Passing the  phone number
	savePhone(phone);
	
	var address = document.forms["contact information"]["address"].value //The address value
	addressCheck(address);//Passing the address.
	
	
	var emailOK = emailCheck(email);
	var phoneOK = phoneCheck(phone);
	var addressOK = addressCheck(address);
	
	saveEmail(emailOK);
	savePhone(phoneOK);
	
	printEveryThing(emailOK, phoneOK, addressOK);
	

}


function printEveryThing(first, second, third){
	if(first == true && second == true && third == true){
		window.location.href = "geoMap.html";
	}	
}


//Validate the phone number
function phoneCheck(phone){
	if(pCheck(phone)){
		var correct = getImage(true, "phone");
		document.getElementById("Phone").appendChild(correct);
		return true;
		savePhone(phone);
		
	}else{
		var wrong = getImage(false, "phone");
		document.getElementById("Phone").appendChild(wrong);
	}
}

//Save the phone into a local storage.
function savePhone(phone){
	localStorage.setItem("phone", phone);//save the value state to a local variable with the name reference phone.
}

//Validate the address
function addressCheck(address){
	splitAddress = address.split(',');
	var city = aCheck(splitAddress[0]);
	var state = aCheck(splitAddress[1]);
	var cityName = splitAddress[0];
	
	if(city & state){
		var correct = getImage(true, "address");
		document.getElementById("Address").appendChild(correct);
		localStorage.City = cityName;
		return true;
	}else{
		var wrong = getImage(false, "address");
		document.getElementById("Address").appendChild(wrong);
	}
}

//Gets the image
function getImage(bool, ID) {
    var image = document.getElementById("image" + ID);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + ID;
    }
    image.src = bool ? './correct.png' : './wrong.png';
    return image;
}

//Checks email
function emailCheck(email) {
	if(email == ""){
		alert("Email must be filled out.");
	}
    atSplit = email.split('@');
    if (atSplit.length == 2 && alphaNumCheck(atSplit[0])) {
        periodSplit = atSplit[1].split('.')
        if (periodSplit.length == 2 && alphaNumCheck(periodSplit[0] + periodSplit[1])) {
			var correct = getImage(true, "email");
			document.getElementById("Email").appendChild(correct);
			saveEmail(email);
			return true;
        }
    }
	var wrong = getImage(false, "email");
			document.getElementById("Email").appendChild(wrong);
    return false;
}

//Save the email into a local storage.
function saveEmail(email){
	localStorage.setItem("email", email);//save the value state to a local variable with the name reference email.
}


//Checks if the input is alpha numeric
function alphaNumCheck(entry) {
    let regex = /^[a-z0-9]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}

//Checks for numeric Characters
function pCheck(entry) {
    let regex = /^[0-9]+$/;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}

//Checks for alpha characters
function aCheck(entry) {
    let regex = /^[A-Za-z]+$/;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}
